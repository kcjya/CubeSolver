

import kociemba
#  U、R、F、D、L、B
import time

def cubeSolve(cube_string):
    try:
        start = time.clock()  # 记录开始时间
        rest = kociemba.solve(cube_string)
        end = time.clock()  # 记录结束时间
        time_ = end - start  # 计算的时间差为程序的执行时间，单位为秒/s
        return rest,time_
    except:
        return None,None
