
import cv2
import numpy as np



def colorRects(xt,yt,size,image):
    # 矩形左上角和右上角的坐标，绘制一个绿色矩形
    xb, yb = (xt + size, yt + size)
    cut_size = 20

    rect_1 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size,
             xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
    rect_2 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size,
             xt + int(size / 6 + size / 3) - cut_size:xt + int(size / 6 + size / 3) + cut_size]
    rect_3 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size,
             xt + int(size / 6 + size * 2 / 3) - cut_size:xt + int(size / 6 + size * 2 / 3) + cut_size]
    rect_4 = image[yt + int(size / 6 + size / 3) - cut_size:yt + int(size / 6 + size / 3) + cut_size,
             xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
    rect_5 = image[yt + int(size / 6 + size / 3) - cut_size:yt + int(size / 6 + size / 3) + cut_size,
             xt + int(size / 6 + size / 3) - cut_size:xt + int(size / 6 + size / 3) + cut_size]
    rect_6 = image[yt + int(size / 6 + size / 3) - cut_size:yt + int(size / 6 + size / 3) + cut_size,
             xt + int(size / 6 + size * 2 / 3) - cut_size:xt + int(size / 6 + size * 2 / 3) + cut_size]
    rect_7 = image[yt + int(size / 6 + size * 2 / 3) - cut_size:yt + int(size / 6 + size * 2 / 3) + cut_size,
             xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
    rect_8 = image[yt + int(size / 6 + size * 2 / 3) - cut_size:yt + int(size / 6 + size * 2 / 3) + cut_size,
             xt + int(size / 6 + size / 3) - cut_size:xt + int(size / 6 + size / 3) + cut_size]
    rect_9 = image[yt + int(size / 6 + size * 2 / 3) - cut_size:yt + int(size / 6 + size * 2 / 3) + cut_size,
             xt + int(size / 6 + size * 2 / 3) - cut_size:xt + int(size / 6 + size * 2 / 3) + cut_size]

    rects = [rect_1, rect_2, rect_3, rect_4, rect_5, rect_6, rect_7, rect_8, rect_9]

    return rects

