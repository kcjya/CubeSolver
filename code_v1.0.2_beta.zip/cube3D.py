import pygame
import random
from pygame.locals import *

from OpenGL.GL import *
from OpenGL.GLU import *

vertices = (
    (1, -1, -1), (1, 1, -1), (-1, 1, -1), (-1, -1, -1),
    (1, -1, 1), (1, 1, 1), (-1, -1, 1), (-1, 1, 1)
)

# 四个定点一个面
edges = ((0, 1), (0, 3), (0, 4), (2, 1), (2, 3), (2, 7), (6, 3), (6, 4), (6, 7), (5, 1), (5, 4), (5, 7))
surfaces = ((0, 1, 2, 3), (3, 2, 7, 6), (6, 7, 5, 4), (4, 5, 1, 0), (1, 5, 7, 2), (4, 0, 3, 6))
colors = ((1, 1, 1), (0, 1, 0), (1, 1, 0), (0, 0, 1), (1, 0, 0), (1, 0.5, 0))
'''          白色-后      绿色-下     黄色-前    蓝色-上         红色-左    橙色-右'''


# colors = ((0, 0, 1), (0, 1, 0), (1, 1, 0), (1, 0.5, 0), (1, 1, 1), (1, 0, 0))


class Cube():
    def __init__(self, id, N, scale):
        self.N = N
        self.scale = scale
        self.init_i = [*id]
        self.current_i = [*id]
        self.rot = [[1 if i == j else 0 for i in range(3)] for j in range(3)]

    def isAffected(self, axis, slice, dir):
        return self.current_i[axis] == slice

    def update(self, axis, slice, dir):

        if not self.isAffected(axis, slice, dir):
            return

        i, j = (axis + 1) % 3, (axis + 2) % 3
        for k in range(3):
            self.rot[k][i], self.rot[k][j] = -self.rot[k][j] * dir, self.rot[k][i] * dir

        self.current_i[i], self.current_i[j] = (
            self.current_i[j] if dir < 0 else self.N - 1 - self.current_i[j],
            self.current_i[i] if dir > 0 else self.N - 1 - self.current_i[i])

    def transformMat(self):
        scaleA = [[s * self.scale for s in a] for a in self.rot]
        scaleT = [(p - (self.N - 1) / 2) * 2.1 * self.scale for p in self.current_i]
        return [*scaleA[0], 0, *scaleA[1], 0, *scaleA[2], 0, *scaleT, 1]

    def draw(self, col, surf, vert, animate, angle, axis, slice, dir):
        glPushMatrix()
        if animate and self.isAffected(axis, slice, dir):
            glRotatef(angle * dir, *[1 if i == axis else 0 for i in range(3)])
        glMultMatrixf(self.transformMat())
        glBegin(GL_QUADS)
        for i in range(len(surf)):
            glColor3fv(colors[i])
            for j in surf[i]:
                glVertex3fv(vertices[j])
        glEnd()
        glPopMatrix()


def _3dcube(lines, cube_lines):
    pygame.init()
    pygame.display.set_caption("3D-CubeSolver")
    icon = pygame.image.load("./res/icon/logo.ico")
    pygame.display.set_icon(icon)
    pygame.display.set_mode((1070, 570), DOUBLEBUF | OPENGL)
    glEnable(GL_DEPTH_TEST)
    # glMatrixMode(GL_PROJECTION)
    # gluPerspective(45, (1070 / 570), 0.1, 50.0)
    # 设置投影
    glMatrixMode(GL_PROJECTION)
    gluPerspective(40, (1070 / 570), 0.1, 50.0)

    # glEnable(GL_DEPTH_TEST)
    # glEnable(GL_LIGHTING)
    # glShadeModel(GL_SMOOTH)
    # glEnable(GL_COLOR_MATERIAL)
    # glEnable(GL_BLEND)
    # glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
    glEnable(GL_LIGHT0)
    glLightfv(GL_LIGHT0, GL_AMBIENT, [0.5, 0.5, 0.5, 1])
    glLightfv(GL_LIGHT0, GL_DIFFUSE, [1.0, 1.0, 1.0, 1])

    gluLookAt(0, 0, 1, 0, 0, 0, 1, 0, 0)

    cr = range(3)
    cubes = [Cube((x, y, z), 3, 2) for x in cr for y in cr for z in cr]
    # 变量处理
    derection = -1
    rot_cube_map = {"LEFT": (-1, 0), "RIGHT": (1, 0), "DOWN": (0, -1), "UP": (0, 1),
                    "LEFTUP":(-1,1), "RIGHTUP":(1,1), "LEFTDOWN":(-1,-1),"RIGHTDOWN":(-1,1)
                    }

    ang_x, ang_y, rot_cube = 40, -22, (0, 0)
    animate, animate_ang, animate_speed = False, 0, 100
    action = (0, 0, 0)
    while True:
        for event in pygame.event.get():
            pass
        if len(lines) > 0:
            if isinstance(lines[0], int):
                derection = lines[0] / abs(lines[0])
                animate_speed = abs(lines[0])
                lines.pop(0)
                # print(rot_slice_map)
            rot_slice_map = {
                "D": (0, 0, derection), "U'": (0, 2, derection), "R": (1, 0, derection),
                "L'": (1, 2, derection), "B": (2, 0, derection), "F'": (2, 2, derection),
                "D'": (0, 0, -1 * derection), "U": (0, 2, -1 * derection), "R'": (1, 0, -1 * derection),
                "L": (1, 2, -1 * derection), "B'": (2, 0, -1 * derection), "F": (2, 2, -1 * derection),
            }
            if not animate and lines[0] in rot_slice_map.keys():
                animate, action = True, rot_slice_map.get(lines[0])

                lines.pop(0)
        else:#还原完成
            pass
        # 转动魔方
        if len(cube_lines) > 0:
            # print(rot_cube_map.get(cube_lines[0]))
            if cube_lines[0] in rot_cube_map.keys() and cube_lines[0] != "RESET":
                rot_cube = rot_cube_map.get(cube_lines[0])
                cube_lines.pop(0)
            elif cube_lines[0] == "RESET":
                ang_x,ang_y = 40, -22
                cube_lines.pop(0)
        else:
            rot_cube = (0, 0)

        ang_x += rot_cube[0] * 2
        ang_y += rot_cube[1] * 2
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        glTranslatef(0, 0, -40)
        glRotatef(ang_y, 0, 1, 0)
        glRotatef(ang_x, 1, 0, 0)

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        if animate:
            if animate_ang >= 90:
                for cube in cubes:
                    cube.update(*action)
                animate, animate_ang = False, 0

        for cube in cubes:
            cube.draw(colors, surfaces, vertices, animate, animate_ang, *action)
        if animate:
            animate_ang += animate_speed

        pygame.display.flip()
        pygame.time.wait(10)

    pygame.quit()
    quit()
# {'window': 27526814, 'hdc': 553718125, 'hinstance': -1508179968}

# if __name__ == '__main__':
#     _3dcube(lines=["B","B'","R","U","D"])
