
import datetime

from PySide2.QtGui import QTextCursor

def Line(where,who,cmdline,_color="rgb(0,250,154)"):
    current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    format = f"<p style=' margin-top:0px; margin-bottom:0px;'><span style='color:rgb(0,255,255);'><i>[{current} ]</i> </span><span style='color:rgb(127,0,255);'> @{who} :</span><span style='color:{_color};'> {cmdline} </span></p>"
    where.append(format)

def tcpFormat(who,all,line,_color="rgb(0,250,154)"):
    current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    format = f"<p style=' margin-top:0px; margin-bottom:0px;'><span style='color:rgb(127,0,255);'><i>[{current} ]</i> </span> <span style='color:{_color};'> {line} </span></p>"
    all+=format
    who.setHtml(all)
    who.moveCursor(QTextCursor.End)
    return all

def sRecvFormat(_who,_all,_line,_from,_color="rgb(0,250,154)"):
    current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    format = f"<p style=' margin-top:0px; margin-bottom:0px;'><span style='color:rgb(0,250,150);'><i>[{current} ]</i> </span> <span style='color:{_color};'> ({_from}){_line} </span></p>"
    _all+=format
    _who.setHtml(_all)
    _who.moveCursor(QTextCursor.End)
    return _all