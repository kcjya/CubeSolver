import time


class Cube_S():
    def __init__(self):
        self.left = [' ',' ',' ',' ']
        self.right = [' ',' ',' ',' ']
        self.FACE = ['U','B','D','F','L','R']
        self.finshed = 0

    def createCube(self,_face = None):
        if _face:
            self.FACE = _face

    def byColorCircle(self,_face,_act,parent,all_step):
        current =""
        stop_time = 0.5
        twice = False
        if "2" in _face:
            twice = True
        _face = _face[0].upper()
        #两只机械手的状态是否水平---初始状态默认时水平的
        left_is_horizontal = True
        lright_is_horizontal = True

        left_is_close = True
        right_is_close = True

        #python记时
        # 方式2：
        time_start_2 = time.time()

        #前面四个是一样（将数据进行分开）
        for i in range(4):
            self.right[i] = self.FACE[i]
        # 左边不一样
        self.left[0] = self.FACE[4] # 左边的第一个等于右边的第五个
        self.left[1] = self.FACE[3] # 左边的第二个等于右边的第四个
        self.left[2] = self.FACE[5] # 左边的第三个等于右边的第六个
        self.left[3] = self.FACE[1] # 左边的第四个等于右边的第二个
        #判断是在左边还是在右边的数组
        if _face in self.right:
            run_time = abs(2 - self.right.index(_face))#需要转动次数为
            if (2 - self.right.index(_face)) > 0:      # 逆时针旋转2 - right[i].index步
                parent.serialSend("K")  #右舵机闭合
                time.sleep(0.1)
                parent.serialSend("J")  #左舵机打开
                time.sleep(0.2)
                for i in range(run_time):
                    parent.serialSend("A")  # 右步进电机 逆时针 90
                    temp_color = self.right[3]
                    for j in range(0, 4).__reversed__():
                        self.right[j] = self.right[j - 1]
                    self.right[0] = temp_color
                time.sleep(stop_time)
                parent.serialSend("I")  #左舵机闭合
                time.sleep(stop_time)
                parent.serialSend("L") #右舵机打开
                time.sleep(0.2)
                for i in range(run_time):
                    parent.serialSend("B")  #右步进电机顺时针90
                time.sleep(stop_time)
                parent.serialSend("K")   #右舵机闭合
                time.sleep(stop_time)

                '''转动底部色块'''
                if _act:
                    if twice:#如果转动两次
                        parent.serialSend("EE") #左步进电机逆时针180
                        time.sleep(stop_time)
                        parent.serialSend("J")  #左舵机打开
                        time.sleep(0.2)
                        parent.serialSend("FF") #左步进电机顺时针180
                    else:
                        parent.serialSend("E") #左步进电机逆时针90
                        time.sleep(stop_time)
                        parent.serialSend("J") #左舵机打开
                        time.sleep(0.2)
                        parent.serialSend("F") #左步进电机顺时针90
                else:
                    if twice:
                        parent.serialSend("FF") #左步进电机顺时针180
                        time.sleep(stop_time)
                        parent.serialSend("J")#左舵机打开
                        time.sleep(0.2)
                        parent.serialSend("EE")#左步进电机逆时针180
                    else:
                        parent.serialSend("E")#左步进电机逆时针90
                        time.sleep(stop_time)
                        parent.serialSend("J")#左舵机打开
                        time.sleep(0.2)
                        parent.serialSend("F")#左步进电机顺时针90
                #记录当前色块
                current = self.right[2]
            else:
                parent.serialSend("K") #右舵机闭合
                time.sleep(stop_time)
                parent.serialSend("J")#左舵机打开
                time.sleep(0.2)
                for i in range(run_time):
                    parent.serialSend("B")#右步进电机顺时针90
                    temp_color = self.right[0]
                    for j in range(0, 3):
                        self.right[j] = self.right[j + 1]
                    self.right[3] = temp_color
                time.sleep(stop_time)
                parent.serialSend("I") #左舵机闭合
                time.sleep(stop_time)
                parent.serialSend("L") #右舵机打开
                time.sleep(0.2)
                for i in range(run_time):
                    parent.serialSend("A")#右步进电机逆时针90
                time.sleep(stop_time)
                parent.serialSend("K") #右舵机闭合
                time.sleep(stop_time)

                '''转动底部色块'''
                if _act:
                    if twice:
                        parent.serialSend("EE")#左步进电机逆时针180
                        time.sleep(stop_time)
                        parent.serialSend("J")#左舵机打开
                        time.sleep(0.2)
                        parent.serialSend("FF")#左步进电机顺时针180
                    else:
                        parent.serialSend("E")#左步进电机逆时针90
                        time.sleep(stop_time)
                        parent.serialSend("J")#左舵机打开
                        time.sleep(0.2)
                        parent.serialSend("F")#左步进电机顺时针90
                else:
                    if twice:
                        parent.serialSend("FF")#左步进电机顺时针180
                        time.sleep(stop_time)
                        parent.serialSend("J")#左舵机打开
                        time.sleep(0.2)
                        parent.serialSend("EE")#左步进电机逆时针180
                    else:
                        parent.serialSend("E")#左步进电机逆时针90
                        time.sleep(stop_time)
                        parent.serialSend("J")#左舵机打开
                        time.sleep(0.2)
                        parent.serialSend("F")#左步进电机顺时针90

                # 记录当前色块
                current = self.right[2]
        else:
            if self.left[0]==_face:
                for i in range(2):
                    parent.serialSend("I") #左舵机闭合
                    time.sleep(stop_time)
                    parent.serialSend("L")#右舵机打开
                    time.sleep(0.2)
                    parent.serialSend("EE")#左步进电机逆时针180
                    for i in range(2):
                        temp_color = self.left[0]
                        for j in range(0, 3):
                            self.left[j] = self.left[j + 1]
                        self.left[3] = temp_color
                    time.sleep(stop_time)
                    parent.serialSend("K") #右舵机闭合
                    time.sleep(stop_time)
                    parent.serialSend("J")#左舵机打开
                    time.sleep(0.2)
                    for i in range(2):
                        parent.serialSend("F")#左步进电机顺时针90
                    time.sleep(stop_time)

                    '''转动底部色块'''
                    if _act:
                        if twice:
                            parent.serialSend("AA")#右步进电机逆时针180
                            time.sleep(stop_time)
                            parent.serialSend("L")#右舵机打开
                            time.sleep(0.2)
                            parent.serialSend("BB")#右步进电机顺时针180
                        else:
                            parent.serialSend("A")#右步进电机逆时针90
                            time.sleep(stop_time)
                            parent.serialSend("L")#右舵机打开
                            time.sleep(0.2)
                            parent.serialSend("B")#右步进电机顺时针90
                    else:
                        if twice:
                            parent.serialSend("BB")#右步进电机顺时针180
                            time.sleep(stop_time)
                            parent.serialSend("L")#右舵机打开
                            time.sleep(0.2)
                            parent.serialSend("AA")#右步进电机逆时针180
                        else:
                            parent.serialSend("B")#右步进电机顺时针90
                            time.sleep(stop_time)
                            parent.serialSend("L")#右舵机打开
                            time.sleep(0.2)
                            parent.serialSend("A")#右步进电机逆时针90

            # 记录当前色块
            current = self.left[2]
        #数据归于一#
        for i in range(4):
            self.FACE[i] = self.right[i]
        self.FACE[4] = self.left[0]
        self.FACE[5] = self.left[2]

        #记时结束
        self.finshed+=1
        time_end_2 = time.time()
        time_ = " 耗时:" + str(round(time_end_2 - time_start_2,3)) + "秒"
        print(f"{self.finshed}/{all_step}steps "+"要求转动的色块:"+_face+"当前转动的色块"+current+time_)

# if __name__ == '__main__':
#     test = Cube_S()
#     print("旋转前:",test.FACE)
#     test.createCube()
#     while True:
#         face = input("请输入面:")
#         test.byColorCircle(face)
#         print(face+"面旋转:",test.FACE)






