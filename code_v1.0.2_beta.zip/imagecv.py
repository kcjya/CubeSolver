import cv2
import numpy as np
from opencv import colorRects
from colormodel import *
from formatcmd import Line

color_temp_dict = {"red": (0, 0, 255), "blue": (255, 0, 0,), "yellow": (0, 255, 255), "green": (0, 255, 0),
                   "orange": (0, 165, 255), "white": (230, 230, 230)}


'''
绘制一个新的魔方的图片
'''
def draw_cube_face(height_, width_, colors):
    cvimage = np.zeros((height_, width_, 3), dtype=np.uint8)
    cv2.rectangle(cvimage, (0, 0), (int(width_ / 3), int(height_ / 3)), color_temp_dict.get(colors[0]), -1)
    cv2.rectangle(cvimage, (int(width_ / 3), 0), (int(width_ * 2 / 3), int(height_ / 3)),
                  color_temp_dict.get(colors[1]), -1)
    cv2.rectangle(cvimage, (int(width_ * 2 / 3), 0), (width_, int(height_ / 3)), color_temp_dict.get(colors[2]), -1)
    cv2.rectangle(cvimage, (0, int(height_ / 3)), (int(width_ / 3), int(height_ * 2 / 3)),
                  color_temp_dict.get(colors[3]), -1)
    cv2.rectangle(cvimage, (int(width_ / 3), int(height_ / 3)), (int(width_ * 2 / 3), int(height_ * 2 / 3)),
                  color_temp_dict.get(colors[4]), -1)
    cv2.rectangle(cvimage, (int(width_ * 2 / 3), int(height_ / 3)), (width_, int(height_ * 2 / 3)),
                  color_temp_dict.get(colors[5]), -1)
    cv2.rectangle(cvimage, (0, int(height_ * 2 / 3)), (int(width_ / 3), height_), color_temp_dict.get(colors[6]), -1)
    cv2.rectangle(cvimage, (int(width_ / 3), int(height_ * 2 / 3)), (int(width_ * 2 / 3), height_),
                  color_temp_dict.get(colors[7]), -1)
    cv2.rectangle(cvimage, (int(width_ * 2 / 3), int(height_ * 2 / 3)), (width_, height_),
                  color_temp_dict.get(colors[8]), -1)

    cv2.rectangle(cvimage, (0, 0), (int(width_ / 3), int(height_ / 3)), (0, 0, 0), 2)
    cv2.rectangle(cvimage, (int(width_ / 3), 0), (int(width_ * 2 / 3), int(height_ / 3)), (0, 0, 0), 2)
    cv2.rectangle(cvimage, (int(width_ * 2 / 3), 0), (width_, int(height_ / 3)), (0, 0, 0), 2)
    cv2.rectangle(cvimage, (0, int(height_ / 3)), (int(width_ / 3), int(height_ * 2 / 3)), (0, 0, 0), 2)
    cv2.rectangle(cvimage, (int(width_ / 3), int(height_ / 3)), (int(width_ * 2 / 3), int(height_ * 2 / 3)), (0, 0, 0),
                  2)
    cv2.rectangle(cvimage, (int(width_ * 2 / 3), int(height_ / 3)), (width_, int(height_ * 2 / 3)), (0, 0, 0), 2)
    cv2.rectangle(cvimage, (0, int(height_ * 2 / 3)), (int(width_ / 3), height_), (0, 0, 0), 2)
    cv2.rectangle(cvimage, (int(width_ / 3), int(height_ * 2 / 3)), (int(width_ * 2 / 3), height_), (0, 0, 0), 2)
    cv2.rectangle(cvimage, (int(width_ * 2 / 3), int(height_ * 2 / 3)), (width_, height_), (0, 0, 0), 2)

    return cvimage


def image_cv(images, readImages, results, cmdline):
    Line(cmdline,"IMAGECV","开始识别魔方图片")
    colors = []
    for image in images:
        img = cv2.imread(image)
        # img_ = cv2.imread(image)
        # img_ = cv2.cvtColor(img_, cv2.COLOR_BGR2HSV)
        rects = colorRects(0, 0, min(img.shape[0], img.shape[1]), img)
        center_color = getColor(rects[4])
        for rect in rects:
            color = getColor(rect)
            colors.append(color)
        results[center_color] = colors
        cvimage = draw_cube_face(200, 200, colors)
        colors.clear()
        # mask = cv2.inRange(img_, hsv_range[0],hsv_range[1])
        readImages[center_color] = image
        # 保存本地
        cv2.imwrite("images/cvimages/" + center_color + ".png", cvimage, [cv2.IMWRITE_JPEG_QUALITY, 0])
        Line(cmdline, "IMAGECV", "No " + str(images.index(image) + 1) + " 图片读取完成")
    Line(cmdline, "IMAGECV", "识别完成")
