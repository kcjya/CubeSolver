import serial
import serial.tools.list_ports


def getPortList():
    comports = list(serial.tools.list_ports.comports())
    if len(comports)>0:
        return comports
    else:
        return []

def openPort(name_,rate_,data_bit,parity_bit,stop_bit,contrl_bit,dtr,rst):
    serial_ = serial.Serial()
    serial_.port = name_        #串口号
    serial_.baudrate = rate_    #波特率
    '''数据位'''
    if data_bit=="5":
        serial_.bytesize = serial.FIVEBITS
    elif data_bit=="6":
        serial_.bytesize = serial.SIXBITS
    elif data_bit=="7":
        serial_.bytesize = serial.SEVENBITS
    elif data_bit=="8":
        serial_.bytesize = serial.EIGHTBITS
    '''校验位'''
    if parity_bit=="无校验":
        serial_.parity = serial.PARITY_NONE
    elif parity_bit=="奇校验":
        serial_.parity = serial.PARITY_ODD
    elif parity_bit=="偶校验":
        serial_.parity = serial.PARITY_EVEN
    '''停止位'''
    if stop_bit=="1":
        serial_.stopbits = serial.STOPBITS_ONE
    elif stop_bit=="1.5":
        serial_.stopbits = serial.STOPBITS_ONE_POINT_FIVE
    elif stop_bit=="2":
        serial_.stopbits = serial.STOPBITS_TWO
    '''控制位'''
    if contrl_bit == "None":
        serial_.xonxoff = False  # 软件流控
        serial_.dsrdtr = False  # 硬件流控 DTR
        serial_.rtscts = False  # 硬件流控 RTS
    elif contrl_bit =="XON/XOFF":
        serial_.xonxoff = True
    else:
        serial_.dsrdtr = dtr
        serial_.rtscts = rst
    #打开串口-如果打开成功返回串口实例
    serial_.open()

    return serial_
