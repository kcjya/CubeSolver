
import os
import cv2


def imageCut(path):
    for path,j,images in os.walk(path):
        for image in images:
            try:
                image_path = path+"\\"+image
                img=cv2.imread(image_path)
                cut = img[0:100,0:100]
                cv2.imwrite(image_path,cut)
            except:
                pass


def renameImage(path):
    for path, j, images in os.walk(path):
        for i in range(0, len(images)):
            try:
                image_path = path + "\\" + images[i]
                os.rename(image_path, path + "\\" + path.split("\\")[-1] + "_" + str(i + 1) + ".png")
            except:
                pass


if __name__ == '__main__':
    imageCut(r"C:\Users\ChuiJiang Kong\Desktop\test")
    # renameImage(r"C:\Users\ChuiJiang Kong\Desktop\test")