
import cv2
import numpy as np
import datetime
from colormodel import *
from formatcmd import Line

def videocv_left(video_data, readcube_rest, cmdline, flag):
    Line(cmdline,"VIDEOCV","左视摄像头初始化成功")
    capture = cv2.VideoCapture(0)  # 0为电脑内置摄像头，1为摄像头外设
    color_list = []
    readflag = 0
    while (True):
        # 摄像头读取,ret为是否成功打开摄像头,true,false。 frame为视频的每一帧图像
        ret, frame = capture.read()
        # 摄像头是和人对立的，将图像左右调换回来正常显示。
        image = cv2.flip(frame, 1)
        #读取多次
        if flag.get("flag"):
            readflag=0
            color_list.clear()
            flag["flag"]=False
        #捕获摄像头
        if flag.get("capture"):
            current = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            cv2.imwrite("images/camera/" + current + "_capture.png", image, [cv2.IMWRITE_JPEG_QUALITY, 0])
            flag["capture"] = False
            Line(cmdline, "VIDEOCV", "捕获摄像头成功 IN: "+"./images/camera/" + current + "_capture.png")
        # 矩形左上角和右上角的坐标，绘制一个绿色矩形
        size=420
        xt,yt = (130, 30)
        xb,yb = (xt+size, yt+size)

        cv2.rectangle(image, (xt,yt), (xb,yb), (255, 0, 0), 2, 4)
        cv2.line(image, (xt,yt+int(size/3)), (xb,yt+int(size/3)), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt, yt + int(size*2 / 3)), (xb, yt + int(size*2 / 3)), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt + int(size / 3), yt), (xt + int(size / 3), yb), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt + int(size*2 / 3), yt), (xt + int(size*2 / 3), yb), (255, 0, 0), 3, cv2.LINE_8)

        cut_size = 20
        rect_1 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
        rect_2 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_3 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]
        rect_4 = image[yt + int(size / 6+size / 3) - cut_size:yt+int(size/6+size / 3) + cut_size, xt+int(size/6) - cut_size:xt+int(size/6) + cut_size]
        rect_5 = image[yt + int(size / 6+size / 3) - cut_size:yt + int(size / 6+size / 3) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_6 = image[yt + int(size / 6+size / 3) - cut_size:yt + int(size / 6+size / 3) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]
        rect_7 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt+int(size/6+size*2 / 3) + cut_size, xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
        rect_8 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt + int(size / 6+size*2 / 3) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_9 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt + int(size / 6+size*2 / 3) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]

        rects = [rect_1,rect_2,rect_3,rect_4,rect_5,rect_6,rect_7,rect_8,rect_9]

        color = None
        if readflag==9:
            Line(cmdline, "VIDEOCV", "左视图颜色读取完成: "+str(color_list))
            readflag+=1
            #读取完成保存数据
            readcube_rest[color_list[4]]=color_list
            # break
        try:
            color = getColor(rects[readflag])
        except:
            pass
        if color!=None and readflag< 9:
            # Line(cmdline, "VIDEOCV", "No "+str(readflag+1)+" 方格颜色读取完成: "+color)
            color_list.append(color)
            readflag+=1
        #共享数据
        video_data.append(image)
        # cv2.imshow("video", img)
        cv2.waitKey(1)
    # cv2.release()
    # cv2.destoryAllWindows()


def videocv_right(video_data, readcube_rest, cmdline, flag):
    Line(cmdline,"VIDEOCV","右视摄像头初始化成功")
    capture = cv2.VideoCapture(1)  # 0为电脑内置摄像头，1为摄像头外设
    color_list = []
    readflag = 0
    while (True):
        # 摄像头读取,ret为是否成功打开摄像头,true,false。 frame为视频的每一帧图像
        ret, frame = capture.read()
        # 摄像头是和人对立的，将图像左右调换回来正常显示。
        image = cv2.flip(frame, 1)
        #读取多次
        if flag.get("flag"):
            readflag=0
            color_list.clear()
            flag["flag"]=False
        #捕获摄像头
        if flag.get("capture"):
            current = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            cv2.imwrite("images/camera/" + current + "_capture.png", image, [cv2.IMWRITE_JPEG_QUALITY, 0])
            flag["capture"] = False
            Line(cmdline, "VIDEOCV", "捕获摄像头成功 IN: "+"./images/camera/" + current + "_capture.png")
        # 矩形左上角和右上角的坐标，绘制一个绿色矩形
        size=420
        xt,yt = (130, 30)
        xb,yb = (xt+size, yt+size)

        cv2.rectangle(image, (xt,yt), (xb,yb), (255, 0, 0), 2, 4)
        cv2.line(image, (xt,yt+int(size/3)), (xb,yt+int(size/3)), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt, yt + int(size*2 / 3)), (xb, yt + int(size*2 / 3)), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt + int(size / 3), yt), (xt + int(size / 3), yb), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt + int(size*2 / 3), yt), (xt + int(size*2 / 3), yb), (255, 0, 0), 3, cv2.LINE_8)

        cut_size = 20
        rect_1 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
        rect_2 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_3 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]
        rect_4 = image[yt + int(size / 6+size / 3) - cut_size:yt+int(size/6+size / 3) + cut_size, xt+int(size/6) - cut_size:xt+int(size/6) + cut_size]
        rect_5 = image[yt + int(size / 6+size / 3) - cut_size:yt + int(size / 6+size / 3) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_6 = image[yt + int(size / 6+size / 3) - cut_size:yt + int(size / 6+size / 3) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]
        rect_7 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt+int(size/6+size*2 / 3) + cut_size, xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
        rect_8 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt + int(size / 6+size*2 / 3) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_9 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt + int(size / 6+size*2 / 3) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]

        rects = [rect_1,rect_2,rect_3,rect_4,rect_5,rect_6,rect_7,rect_8,rect_9]

        color = None
        if readflag==9:
            Line(cmdline, "VIDEOCV", "右视图颜色读取完成: "+str(color_list))
            readflag+=1
            #读取完成保存数据
            readcube_rest[color_list[4]]=color_list
            # break
        try:
            color = getColor(rects[readflag])
        except:
            pass
        if color!=None and readflag< 9:
            # Line(cmdline, "VIDEOCV", "No "+str(readflag+1)+" 方格颜色读取完成: "+color)
            color_list.append(color)
            readflag+=1
        #共享数据
        video_data.append(image)
        # cv2.imshow("video", img)
        cv2.waitKey(1)
    # cv2.release()
    # cv2.destoryAllWindows()


def videocv_up(video_data, readcube_rest, cmdline, flag):
    Line(cmdline,"VIDEOCV","上视摄像头初始化成功.")
    capture = cv2.VideoCapture(1)  # 0为电脑内置摄像头，1为摄像头外设
    color_list = []
    readflag = 0

    while (True):
        # image = cv2.imread("./testface.jpg")
        # 摄像头读取,ret为是否成功打开摄像头,true,false。 frame为视频的每一帧图像
        ret, frame = capture.read()
        # 摄像头是和人对立的，将图像左右调换回来正常显示。
        image = cv2.flip(frame, 1)

        #读取多次
        if flag.get("flag"):
            readflag=0
            color_list.clear()
            flag["flag"]=False
        #捕获摄像头
        if flag.get("capture"):
            current = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            cv2.imwrite("images/camera/" + current + "_capture.png", image, [cv2.IMWRITE_JPEG_QUALITY, 0])
            flag["capture"] = False
            Line(cmdline, "VIDEOCV", "捕获摄像头成功 IN: "+"./images/camera/" + current + "_capture_up.png")
        '''图像矫正'''
        # 原图中书本的四个角点(左上、右上、左下、右下),与变换后矩阵位置
        before = np.float32([[80, 0], [350, 0], [0, 150], [420, 210]])
        after = np.float32([[0, 0], [420, 0], [0, 420], [420, 420]])
        # 单应变换-图像校正
        h = cv2.getPerspectiveTransform(before, after)
        image = cv2.warpPerspective(image, h, (420, 420))
        # 矩形左上角和右上角的坐标，绘制一个绿色矩形
        size=420
        xt,yt = (0, 0)
        xb,yb = (xt+size, yt+size)

        cv2.rectangle(image, (xt,yt), (xb,yb), (255, 0, 0), 2, 4)
        cv2.line(image, (xt,yt+int(size/3)), (xb,yt+int(size/3)), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt, yt + int(size*2 / 3)), (xb, yt + int(size*2 / 3)), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt + int(size / 3), yt), (xt + int(size / 3), yb), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt + int(size*2 / 3), yt), (xt + int(size*2 / 3), yb), (255, 0, 0), 3, cv2.LINE_8)

        cut_size = 20
        rect_1 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
        rect_2 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_3 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]
        rect_4 = image[yt + int(size / 6+size / 3) - cut_size:yt+int(size/6+size / 3) + cut_size, xt+int(size/6) - cut_size:xt+int(size/6) + cut_size]
        rect_5 = image[yt + int(size / 6+size / 3) - cut_size:yt + int(size / 6+size / 3) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_6 = image[yt + int(size / 6+size / 3) - cut_size:yt + int(size / 6+size / 3) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]
        rect_7 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt+int(size/6+size*2 / 3) + cut_size, xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
        rect_8 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt + int(size / 6+size*2 / 3) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_9 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt + int(size / 6+size*2 / 3) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]

        rects = [rect_1,rect_2,rect_3,rect_4,rect_5,rect_6,rect_7,rect_8,rect_9]

        color = None
        if readflag==9:
            Line(cmdline, "VIDEOCV", "上视图颜色读取完成: "+str(color_list))
            readflag+=1
            # break

        try:
            color = getColor(rects[readflag])
        except:
            pass
        if color!=None and readflag< 9:
            #第几个放个颜色读取
            # Line(cmdline, "VIDEOCV", "No "+str(readflag+1)+" 方格颜色读取完成: "+color)
            color_list.append(color)
            readflag+=1
        #共享数据
        video_data.append(image)
        # cv2.imshow("video", img)
        cv2.waitKey(1)

    # cv2.release()
    # cv2.destoryAllWindows()