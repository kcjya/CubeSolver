# 添加各种包
'''pyside2包'''
import json

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
from PySide2.QtMultimedia import *

'''系统包'''
import os
import cv2
import sys
import win32gui
import pygame
import cvserial
import sklearn
import kociemba
import datetime
import socketserver
import multiprocessing

'''自定义包'''
import tcp
import cube
import values
import opencv
import cube3D
import videocv
import imagecv
import main_ui
import popcamera
from cube_struct import*
from formatcmd import Line,sRecvFormat,tcpFormat

from OpenGL.GL import *
from OpenGL.GLU import *


'''
    作用：主窗口类
    继承自：QMainWindow
'''

class MainWindow(main_ui.QMainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.main_ui = main_ui.Ui_MainWindow()
        self.main_ui.setupUi(self)

        self.setFixedSize(1500, 920)
        self.setWindowTitle("CBSolver by KONG v1.0.2 Beta")
        self.main_ui.video.resize(450, 340)
        # self.main_ui.video.move(400, 0)

        # 全局变量
        self.lines = ""
        self.tcpline = ""  # tcp
        # 启动一个线程，等待结束
        self.manager = multiprocessing.Manager()
        # 线程数据共享字典
        self.video_data = self.manager.list()
        self.readcube_rest = self.manager.dict()
        self.cmdline = self.manager.list()
        #tcp发送字段
        self.sendline = self.manager.list()
        # 图片处理CV
        self.readImages = self.manager.dict()
        self.return_colors = self.manager.dict()
        self.flag = self.manager.dict()
        self.flag["flag"] = False
        self.cameraisopen = True
        # 3d魔方视觉窗口的命令行
        self._3dcubeslice = self.manager.list()
        self._3dcubeangle = self.manager.list()
        # 串口实例
        self.serial_ = None
        self.serial_recv=""
        # 串口接收数据大小
        self.RX = 0
        self.TX = 0
        #json变量初始化
        self.keys,self.solve_dict,self.color_dict,self.step_motor,self.color_list = values.valuesInit()

        self.pop_up_camera = popcamera.PopCamera("相机上视图")
        self.pop_down_camera = popcamera.PopCamera("相机下视图")
        self.pop_left_camera = popcamera.PopCamera("相机左视图")
        self.pop_right_camera = popcamera.PopCamera("相机右视图")

        # 软件个窗口的初始化设置
        self.windowsInit()
        # 相关定时器初始化
        self.timersInit()
        # 相关按钮初始化
        self.buttonsInit()
        #摄像头进程开启
        self.cv_proc = multiprocessing.Process(target=videocv.videocv_left,
                                               args=(self.video_data, self.readcube_rest, self.cmdline, self.flag,))
        self.cv_proc.start()

        copyright = QLabel("CBSolver v1.0.2 Beta  @KONG 2023")
        self.main_ui.statusbar.addPermanentWidget(copyright)

        self.serial_state = QLabel("串口未打开!")
        self.serial_state.setStyleSheet("color:rgb(255,0,0);")
        self.main_ui.statusbar.addWidget(self.serial_state)

        self.rxtx = QLabel(f"RX:{str(self.RX)} bytes TX:{str(self.TX)} bytes")
        self.main_ui.statusbar.addWidget(self.rxtx)


    '''
        作用：软件各个窗口特征的初始化
        参数：无
        返回值：无
    '''

    def windowsInit(self):
        self.main_ui.app_setting_win.close()
        self.main_ui.about_win.close()
        self.main_ui.tool_window.close()

        self.main_ui.camera_view_win.setFixedWidth(430)
        self.main_ui.center.resize(self.width() - 430, self.height() - 350)
        self.main_ui.console_win_view.setMinimumHeight(300)
        self.main_ui.app_setting_win.setFixedSize(900, 600)
        self.main_ui.about_win.setFixedSize(900, 600)
        self.main_ui.tool_window.setFixedSize(600, 400)

        self.main_ui.app_setting_win.setFloating(True)
        self.main_ui.about_win.setFloating(True)
        self.main_ui.tool_window.setFloating(True)



    '''
        作用：软件各个定时器事件的初始化
        参数：无
        返回值：无
    '''

    def timersInit(self):
        # 摄像机机位1试试刷新
        self.videotim_1 = QTimer(self)
        self.videotim_1.setInterval(1)
        self.videotim_1.timeout.connect(self.showVideo_1)
        self.videotim_1.start()
        # 实时获取console
        self.console_tim = QTimer(self)
        self.console_tim.setInterval(100)
        self.console_tim.timeout.connect(self.updataConsole)
        self.console_tim.start()
        # 实时获取image cv处理的结果
        self.imagecv_tim = QTimer(self)
        self.imagecv_tim.setInterval(1)
        self.imagecv_tim.timeout.connect(self.updataImagecvResult)
        # 实时接收串口信息
        self.serial_tim = QTimer(self)
        self.serial_tim.setInterval(300)
        self.serial_tim.timeout.connect(self.recvSerial)
        # 串口定时发送
        self.timer_send = QTimer(self)
        self.timer_send.setInterval(20000)
        self.timer_send.timeout.connect(self.sendBytime)

    '''
        作用：软件各个按钮事件的初始化
        参数：无
        返回值：无
        注意：在程序一开始的时候调用
    '''

    def buttonsInit(self):
        # 弹出个相机大窗口
        self.main_ui.top_camera.clicked.connect(self.pop_up_camera.show)
        self.main_ui.down_camera.clicked.connect(self.pop_down_camera.show)
        self.main_ui.left_camera.clicked.connect(self.pop_left_camera.show)
        self.main_ui.right_camera.clicked.connect(self.pop_right_camera.show)
        # 导出控制栏历史信息
        self.main_ui.out_console.triggered.connect(self.outConsole)
        # 快捷键
        QShortcut(QKeySequence(self.tr("Ctrl+O")), self, self.outConsole)
        # 识别一次颜色
        self.main_ui.read_once.clicked.connect(self.readColor)
        # 关闭摄像头-打开摄像头
        self.main_ui.close_camera.clicked.connect(self.closeCmera)
        self.main_ui.open_camera.clicked.connect(self.openCamera)
        # toolbox 按钮初始化
        # 退出程序-快捷键
        QShortcut(QKeySequence(self.tr("Ctrl+Q")), self, self.close)
        QShortcut(QKeySequence(self.tr("ESC")), self, self.close)
        # QShortcut(QKeySequence(self.tr("C")), self, self.close)
        # QShortcut(QKeySequence(self.tr("Q")), self, self.close)
        self.main_ui.close.triggered.connect(self.close)
        self.main_ui.close_win.triggered.connect(self.close)
        self.main_ui.quit_app.triggered.connect(self.close)
        # 导入图片
        QShortcut(QKeySequence(self.tr("Ctrl+I")), self, self.importImage)
        QShortcut(QKeySequence(self.tr("I")), self, self.importImage)
        self.main_ui.import_image.triggered.connect(self.importImage)
        # 保存魔方展开图
        QShortcut(QKeySequence(self.tr("Ctrl+S")), self, self.saveCubeex)
        # QShortcut(QKeySequence(self.tr("S")), self, self.saveCubeex)
        self.main_ui.save_cube_ex.triggered.connect(self.saveCubeex)
        self.main_ui.save_cube_ex_image.clicked.connect(self.saveCubeex)
        # 导入或者保存相关文件
        self.main_ui.camera_view.triggered.connect(self.cameraWinView)
        self.main_ui.console_view.triggered.connect(self.consoleWinView)
        self.main_ui.global_setting_view.triggered.connect(self.settingView)
        self.main_ui.about_view.triggered.connect(self.aboutView)
        # 弹出设置窗口
        self.main_ui.global_setting.triggered.connect(self.appSettingwin)  # 打开设置窗口
        self.main_ui.app_setting.triggered.connect(self.appSettingwin)
        self.main_ui.seral_setting.triggered.connect(self.appSettingwin)
        self.main_ui.tcp_setting.triggered.connect(self.appSettingwin)
        # 弹出帮助窗口
        self.main_ui.help_text.triggered.connect(self.aboutWin)
        self.main_ui.about.triggered.connect(self.aboutWin)
        # 回车发送
        self.main_ui.send.returnPressed.connect(self.sendData)
        # 发送解决方案
        self.main_ui.send_solve.clicked.connect(self.sendSolve)
        # 下载帮助文档
        self.main_ui.download_help.clicked.connect(self.downloadHelp)
        # 创建-关闭tcp服务器
        self.main_ui.create_server_quk.clicked.connect(self.createTcp)
        self.main_ui.close_server.clicked.connect(self.closeTcpServer)
        # 操作界面的转换
        self.main_ui.center.currentChanged.connect(self.currentChange)
        # 工具箱窗口显示
        self.main_ui.cut_images.triggered.connect(self.main_ui.tool_window.show)
        self.main_ui.rename_files.triggered.connect(self.main_ui.tool_window.show)
        # 通过用户传进来的cube字符串进行解魔方
        self.main_ui.solver_cube_bycubestring.clicked.connect(self.solverByself)
        # 摄像头捕获
        self.main_ui.capture_camera.clicked.connect(self.captureCamera)
        # 打乱魔方-还原魔方
        # self.main_ui.upset_cube
        self.main_ui.revert_cube.triggered.connect(self.revertCube)
        # 串口检测按钮
        self.main_ui.check_com.clicked.connect(self.checkSerial)
        self.main_ui.open_com.clicked.connect(self.openSerial)
        self.main_ui.close_com.clicked.connect(self.closeSerial)
        self.main_ui.clear_send.clicked.connect(self.clearSend)
        self.main_ui.clear_recv.clicked.connect(self.clearRecv)
        self.main_ui.save_log.clicked.connect(self.saveLog)
        self.main_ui.save_send.clicked.connect(self.saveSend)
        self.main_ui.load_log.clicked.connect(self.loadLog)
        self.main_ui.com_send.clicked.connect(self.comSend)
        # 关闭串口按钮失效
        self.main_ui.close_com.setEnabled(False)
        self.main_ui.close_server.setEnabled(False)
        #生成3D视图
        self.main_ui.show_3d_cube.clicked.connect(self.create3DCube)
        self.main_ui.show_3d_cube_.clicked.connect(self.create3DCube)
        #清空控制台
        self.main_ui.clear_console.clicked.connect(self.main_ui.line.clear)
        #清空发送缓存
        # self.main_ui.clear_send_buffer.clicked.connect(self.sendline.clear)
        #用户输入的魔方字串求解
        self.main_ui.solver_cube_bycubestring.clicked.connect(self.solveCubeByself)

        #控制舵机
        self.main_ui.left_open.clicked.connect(self.motor_leftOpen)
        self.main_ui.left_close.clicked.connect(self.motor_leftClose)
        self.main_ui.right_open.clicked.connect(self.motor_rightOpen)
        self.main_ui.right_close.clicked.connect(self.motor_rightClose)
        #控制步进电机
        self.main_ui.motor_L.clicked.connect(self.motorL)
        self.main_ui.motor_L_.clicked.connect(self.motorL_)
        self.main_ui.motor_B.clicked.connect(self.motorB)
        self.main_ui.motor_B_.clicked.connect(self.motorB_)

    '''舵机控制函数-左右开合-串口信息发送'''
    def motor_leftClose(self):
        if self.serial_:
            self.serial_.write(bytes("I".encode('utf-8')))
        else:
            Line(self.cmdline, "SERIAL", "请先打开串口并连接.")
    def motor_leftOpen(self):
        if self.serial_:
            self.serial_.write(bytes("J".encode('utf-8')))
        else:
            Line(self.cmdline, "SERIAL", "请先打开串口并连接.")
    def motor_rightClose(self):
        if self.serial_:
            self.serial_.write(bytes("K".encode('utf-8')))
        else:
            Line(self.cmdline, "SERIAL", "请先打开串口并连接.")
    def motor_rightOpen(self):
        if self.serial_:
            self.serial_.write(bytes("L".encode('utf-8')))
        else:
            Line(self.cmdline, "SERIAL", "请先打开串口并连接.")

    '''步进电机串口控制信息发送'''
    def motorL(self):
        if self.serial_:    #左臂-顺时针转动90°
            self.serial_.write(bytes("A".encode('utf-8')))
        else:
            Line(self.cmdline, "SERIAL", "请先打开串口并连接.")
    def motorL_(self):
        if self.serial_:    #左臂-逆时针转动90°
            self.serial_.write(bytes("B".encode('utf-8')))
        else:
            Line(self.cmdline, "SERIAL", "请先打开串口并连接.")
    def motorB(self):
        if self.serial_:    #右臂-顺时针转动90°
            self.serial_.write(bytes("E".encode('utf-8')))
        else:
            Line(self.cmdline, "SERIAL", "请先打开串口并连接.")
    def motorB_(self):
        if self.serial_:    #右臂-逆时针转动90°
            self.serial_.write(bytes("F".encode('utf-8')))
        else:
            Line(self.cmdline, "SERIAL", "请先打开串口并连接.")

    '''
    使用用户自己的魔方字串获取魔方的还原字串
    '''
    def solveCubeByself(self):
        cubetxt = self.main_ui.cube_string_self.text()
        if cubetxt:
            rest,time_ = cube.cubeSolve(cubetxt)
            self.main_ui.solve_string_self.setText(rest)
            Line(self.cmdline, "SELFCUBE", f"已得到解决方案 用时:{round(time_,4)}ms.")
        Line(self.cmdline, "SELFCUBE", "请输入正确的魔方字串.")
    def create3DCube(self):
        Line(self.cmdline, "3DCUBE", "已经创建3D魔方视图" )
        self.main_ui.center.setCurrentIndex(2)

    '''
    还原魔方
    '''
    def revertCube(self):
        self.main_ui.center.setCurrentIndex(2)
        self._3dcubeslice.append(10)         #设置魔方的转动速度
        for item in self.cube_solve.split(" "):
            if "2" in item: #如果有两个就添加两次
                self._3dcubeslice.append(item[:-1])
                self._3dcubeslice.append(item[:-1])
            else:
                self._3dcubeslice.append(item)#否则就添加一次
    '''
    3D魔方模拟视图-openGL3D
    '''
    def cube3DView(self):
        self.cube3d_proc = multiprocessing.Process(target=cube3D._3dcube, args=(self._3dcubeslice, self._3dcubeangle,))
        self.cube3d_proc.start()
        # self.cube3d_proc.join()   #启动openGL线程显示魔方3d视图
        hwnd = False
        while not hwnd:             #通过无线循环获取窗口的句柄，将该窗口嵌入到qt界面当中
            # 获取句柄
            hwnd = win32gui.FindWindow("pygame", "3D-CubeSolver")
        window = QWindow.fromWinId(hwnd)
        window = QWidget.createWindowContainer(window)
        self.main_ui.cube_3d.addWidget(window)

    def closeCmera(self):
        Line(self.cmdline, "CAMERA", "摄像头已关闭.")
        self.cameraisopen = False

    def openCamera(self):
        Line(self.cmdline, "CAMERA", "摄像头已打开.")
        self.cameraisopen = True

    def captureCamera(self):
        self.flag["capture"] = True

    def solverByself(self):
        self_cube = self.main_ui.cube_string_self.text()
        if self_cube:
            result, time_ = cube.cubeSolve(self_cube)
            self.main_ui.solve_string_self.setText(result)
            Line(self.cmdline, "SOLVER", "完成魔方还原:" + result)
            Line(self.cmdline, "SOLVER", f"总用时: {round(time_,4)}ms.")

    def createTcp(self):
        try:
            server_data = self.main_ui.server_data.text().split(":")
            ip = server_data[0]
            port = server_data[1]
            # 创建TCP实例
            self.tcp_proc = multiprocessing.Process(target=tcp.createTcp, args=(ip, port, self.sendline, self.cmdline,))
            self.tcp_proc.start()
            self.main_ui.close_server.setEnabled(True)
            self.main_ui.create_server_quk.setEnabled(False)
        except:
            Line(self.cmdline,"TCPSERVER","TCP服务器端创建失败，请点击关闭后检查格式是否为'127.0.0.0:8000'或更换端口重试. ",color="rgb(255,0,0)")
            self.main_ui.close_server.setEnabled(False)

    def closeTcpServer(self):
        try:        #关闭tcp服务器
            self.sendline.append("__closetcp__")
            Line(self.cmdline, "TCPSERVER", "TCP服务器端关闭成功.")
            self.tcp_proc.kill()
        except:
            Line(self.cmdline, "TCPSERVER", "TCP服务器可能已经关闭.",
                 color="rgb(255,0,0)")
        #关闭之后使能关闭按钮
        self.main_ui.close_server.setEnabled(False)
        self.main_ui.create_server_quk.setEnabled(True)
    # def updataSenddata(self):
    #     send_data.append()

    def readColor(self):
        self.flag["flag"] = True

    '''
        作用：下载帮助文档到本地
        参数：无
        返回值：无
    '''

    def downloadHelp(self):
        help = "欢迎使用魔方助手"
        out_path = QFileDialog.getSaveFileName(self, '保存文件', 'help', 'TXT files (*.txt)')[0]
        if out_path:
            with open(out_path, "w") as fp:
                fp.write(help)
                Line(self.cmdline, "HELPER", "已下载到:"+out_path)

    '''作用：显示设置的窗口'''

    def appSettingwin(self):
        self.main_ui.about_win.close()
        self.main_ui.app_setting_win.show()

    '''作用：显示关于的窗口'''

    def aboutWin(self):
        self.main_ui.app_setting_win.close()
        self.main_ui.about_win.show()

    '''作用：是否相机视角窗口'''

    def cameraWinView(self, check):
        if check:
            self.main_ui.camera_view.setChecked(check)
            self.main_ui.camera_view_win.show()
        else:
            self.main_ui.camera_view.setChecked(check)
            self.main_ui.camera_view_win.close()

    '''作用：是否显示控制台'''

    def consoleWinView(self, check):
        if check:
            self.main_ui.console_view.setChecked(check)
            self.main_ui.console_win_view.show()
        else:
            self.main_ui.console_view.setChecked(check)
            self.main_ui.console_win_view.close()

    '''是否显示设置窗口'''

    def settingView(self, check):
        if check:
            self.main_ui.global_setting_view.setChecked(check)
            self.main_ui.app_setting_win.show()
        else:
            self.main_ui.global_setting_view.setChecked(check)
            self.main_ui.app_setting_win.close()

    '''是否显示关于帮助窗口'''

    def aboutView(self, check):
        if check:
            self.main_ui.about_view.setChecked(check)
            self.main_ui.about_win.show()
        else:
            self.main_ui.about_view.setChecked(check)
            self.main_ui.about_win.close()

    '''
        作用：保存到本地从opencv中读取的6面魔方的信息
        参数：无
        返回值：无
        注意：本身是一个按钮的回调函数
    '''

    def saveCubeex(self):
        out_path = \
        QFileDialog.getSaveFileName(self, '保存文件', 'cube_image', 'Image files (*.png);; Image files (*.jpg)')[0]
        if out_path:
            # 截取屏幕内容成图片
            screen = QGuiApplication.primaryScreen()
            pixmap = screen.grabWindow(self.main_ui.center.winId())
            pixmap.save(out_path);
            # with open(out_path,"wb") as fp:
            #     fp.write("")
            Line(self.cmdline, "HELPER", "已保存到:" + out_path)
    '''
        作用：从本地导入6张图片，从图片解算出魔方的揭发返回给用户
        参数：无
        返回值：无
        注意：本身是一个按钮的回调函数
    '''

    def importImage(self):
        t = self.main_ui
        self.result_images = [t.read_image_1, t.read_image_2, t.read_image_3, t.read_image_4, t.read_image_5,
                              t.read_image_6]
        self.cv_images = [t.return_image_1, t.return_image_2, t.return_image_3, t.return_image_4, t.return_image_5,
                          t.return_image_6]
        images = QFileDialog.getOpenFileNames(self, "选择图片文件")[0]  # 选择目录，返回选中的路径
        if len(images) == 6:
            self.readImages.clear()
            self.import_images = images
            self.image_cv_proc = multiprocessing.Process(target=imagecv.image_cv, args=(
            self.import_images, self.readImages, self.return_colors, self.cmdline,))
            self.image_cv_proc.start()
            self.imagecv_tim.start()
            #启动3d魔方程序
            # 测试
            # self.cube3DView()
        else:
            Line(self.cmdline, "IMPORT", "导入图片数量不为6张, 导入失败.")

    def currentChange(self,current):
        if current==0:
            pass
        elif current==1:
            t = self.main_ui
            colors = ["orange", "white", "blue", "red", "green", "yellow"]
            cube_faces = [t.cube_ex_left, t.cube_ex_back, t.cube_ex_up, t.cube_ex_right, t.cube_ex_down, t.cube_ex_front]
            for face in cube_faces:
                index = cube_faces.index(face)
                face.setStyleSheet("border-image: url(./images/cvimages/" + colors[index] +
                                   ".png);background-color: rgba(255, 255, 255, 0);color: rgb(0, 0, 0);")
        #3d视图窗口
        elif current==2:

            Line(self.cmdline,"3DCUBE","W:向上旋转 S:向下旋转 A:向左旋转 D:向右旋转 Q:左上旋转 Z:左下旋转 E:右上旋转 X:右下旋转.",color="rgb(255,0,0)")
            # if self.
        elif current == 3:
            pass


    '''
         作用：更新图片识别的结果
         参数：无
         返回值：无
         注意：本身是一个定时器的回调函数，识别结束，定时器自动关闭,循序由程序内定
     '''

    def updataImagecvResult(self):
        finish = 0
        colors = ["blue", "red", "yellow", "green", "orange", "white"]
        for readcolor in self.result_images:
            try:
                index = self.result_images.index(readcolor)
                readcolor.setStyleSheet("border-image: url(" + self.readImages.get(
                    colors[index]) + ");background-color: rgba(255, 255, 255, 0);color: rgb(0, 0, 0);")

                finish += 1
                self.cv_images[index].setStyleSheet("border-image: url(./images/cvimages/" + colors[index] +
                                                    ".png);background-color: rgba(255, 255, 255, 0);color: rgb(0, 0, 0);")

            except:
                pass

        # 如果finish次数大于6，说明完成读取
        if finish >= 6:
            self.imagecv_tim.stop()
            self.image_cv_proc.kill()
            Line(self.cmdline, "IMAGECV", "\"(蓝)中心块:\"" + str(self.return_colors.get("blue")))
            Line(self.cmdline, "IMAGECV", "\"(红)中心块:\"" + str(self.return_colors.get("red")))
            Line(self.cmdline, "IMAGECV", "\"(黄)中心块:\"" + str(self.return_colors.get("yellow")))
            Line(self.cmdline, "IMAGECV", "\"(绿)中心块:\"" + str(self.return_colors.get("green")))
            Line(self.cmdline, "IMAGECV", "\"(橙)中心块:\"" + str(self.return_colors.get("orange")))
            Line(self.cmdline, "IMAGECV", "\"(白)中心块:\"" + str(self.return_colors.get("white")))
            # 获取魔方的字符串
            cs = self.getCubeString()
            self.main_ui.cube_string.setText(cs)
            Line(self.cmdline, "IMAGECV", "\"魔方字块-\"" + cs)
            self.cube_solve, time_ = cube.cubeSolve(cs)
            if self.cube_solve:
                self.main_ui.solve_string.setText(self.cube_solve)
                Line(self.cmdline, "IMAGECV", "\"魔方解决方案为-\"" + self.cube_solve)
                solve_list = self.cube_solve.split(" ")
                for str_ in solve_list:
                    Line(self.cmdline, "IMAGECV", self.solve_dict.get(str_))
                Line(self.cmdline, "IMAGECV", f"\"(共:{str(len(solve_list))}步-用时:{round(time_,4)}ms).")
                self._3dcubeslice.append(-100)
                # 导入3d绘图进程-先转换魔方字符串-反转
                for item in solve_list[::-1]:
                    if "2" in item:
                        self._3dcubeslice.append(item[:-1])
                        self._3dcubeslice.append(item[:-1])
                    else:
                        self._3dcubeslice.append(item)
            else:
                Line(self.cmdline, "IMAGECV", "创建解决方案失败.", color="red")

    '''
         作用：获取魔方的字段
         参数：无
         返回值：无
         描述：color_list必须按照一定的循序去读取，对应的需要在本地文档里面修改
     '''

    def getCubeString(self):
        cube_string = ""
        # colors = ["blue", "orange", "yellow", "green", "red", "white"]
        for center_color in self.color_list:
            for color in self.return_colors.get(center_color):
                cube_string += self.color_dict.get(color)

        return cube_string

    '''
        作用：定时从opencv.py文档中获取已经完成的命令
        参数：无
        返回值：无
        注意：本身是一个定时器的回调函数
    '''

    def updataConsole(self):
        # print(opencv.cmd.getValue(0))
        try:
            # self.main_ui.line.setHtml()
            self.lines += self.cmdline[0]
            self.main_ui.line.setHtml(self.lines)
            self.main_ui.line.moveCursor(QTextCursor.End)
            self.cmdline.pop(0)
        except:
            pass

    '''
        作用：将软件控制台的类容输出为txt文档以供参考
        参数：无
        返回值：无
        注意：本身是一个按钮的回调函数
    '''

    def outConsole(self):
        out_path = QFileDialog.getSaveFileName(self, '保存文件', 'console', 'HTML files (*.html)')[0]
        if out_path:
            with open(out_path, "w") as fp:
                fp.write(self.lines)
            Line(self.cmdline, "OUT", "导出成功到: " + out_path)

    '''
        作用：在软件界面实时更新Label对象，让其成为视频
        参数：无
        返回值：无
        注意：本身是一个定时器的回调函数
    '''

    def showVideo_1(self):
        if len(self.video_data) > 0 and self.cameraisopen:
            video = self.cvimg_to_qtimg(self.video_data[0], self.main_ui.video.width(), self.main_ui.video.height())
            video_pop = self.cvimg_to_qtimg(self.video_data[0], self.pop_up_camera.popcamera_ui.video.width(),
                                            self.pop_up_camera.popcamera_ui.video.height())

            self.main_ui.video.setPixmap(video)
            self.main_ui.video_2.setPixmap(video)
            self.main_ui.video_3.setPixmap(video)
            self.main_ui.video_4.setPixmap(video)
            # 弹出的相机视角更新程序
            if self.pop_up_camera.isVisible():
                self.pop_up_camera.setVideo(video_pop)
            if self.pop_down_camera.isVisible():
                self.pop_down_camera.setVideo(video_pop)
            if self.pop_left_camera.isVisible():
                self.pop_left_camera.setVideo(video_pop)
            if self.pop_right_camera.isVisible():
                self.pop_right_camera.setVideo(video_pop)

        elif self.cameraisopen == False:
            self.main_ui.video.setPixmap("./res/png/camera_close_s.png")
            self.main_ui.video_2.setPixmap("./res/png/camera_close_s.png")
            self.main_ui.video_3.setPixmap("./res/png/camera_close_s.png")
            self.main_ui.video_4.setPixmap("./res/png/camera_close_s.png")
            # 弹出的相机视角更新程序
            if self.pop_up_camera.isVisible():
                self.pop_up_camera.setVideo("./res/png/camera_close.png")
            if self.pop_down_camera.isVisible():
                self.pop_down_camera.setVideo("./res/png/camera_close.png")
            if self.pop_left_camera.isVisible():
                self.pop_left_camera.setVideo("./res/png/camera_close.png")
            if self.pop_right_camera.isVisible():
                self.pop_right_camera.setVideo("./res/png/camera_close.png")
        try:
            self.video_data.pop(0)
        except:
            pass

    '''
    作用：将opencv读取的帧转换为qt的QPixmap类型
    参数：(frame)opencv的对象，(width, height)图片的大小
    返回值：qt类型QPixmap
    '''

    def cvimg_to_qtimg(self, frame, width, height):
        # 显示图像
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # 格式转换
        img = QImage(frame.data, frame.shape[1], frame.shape[0], frame.shape[1] * 3, QImage.Format_RGB888)
        pix = QPixmap(img).scaled(width, height)

        return pix

    '''命令行窗口的发送函数'''
    def sendData(self):
        self.cmdkeys = ["quit", "help", "clear", "cls"]
        send_data = self.main_ui.send.text()
        if send_data:
            self.main_ui.send.clear()
            # 如果不是软件的命令就发送给下位机
            if send_data not in self.cmdkeys:
                self.sendline.append(send_data)
            # 执行相对应的软件命令
            else:
                if send_data == "quit":
                    self.close()
                elif send_data == "help":
                    with open("file/help.cbs", "r", encoding="utf-8") as fp:
                        help = fp.read()
                        self.main_ui.line.clear()
                        self.main_ui.line.setText(help)
                elif send_data == "clear" or send_data == "cls":
                    self.lines = ""
                    self.main_ui.line.clear()

        else:
            Line(self.cmdline, "GLOBAL", "内容不能为空.", _color="red")

    '''发送解决方案-默认发送至串口'''
    def sendSolve(self):
        try:
            self.sendline.append(self.cube_solve)
            for i in self.sendline:
                print(i)
        except:
            Line(self.cmdline, "GLOBAL", "还没有解决方案.", _color="red")

        self.temp = list()
        solve_list = self.cube_solve.split(" ")
        # 导入3d绘图进程-先转换魔方字符串-反转
        for item in solve_list:
            if "'" in item:
                self.temp.append(item[:-1].lower())
            else:
                self.temp.append(item)

        print(self.temp)

        test = Cube_S()
        # 发送到串口
        for item in self.temp:
            test.byColorCircle(item, item[0].islower(), self,len(self.temp))


    def serialSend(self,_line):
        self.main_ui.send_msg.clear()
        self.main_ui.send_msg.setText(_line)
        self.comSend()

    # 串口相关
    def checkSerial(self):
        self.ports = cvserial.getPortList()
        if len(self.ports) > 0:
            self.main_ui.com.clear()
            for port in self.ports:
                self.main_ui.com.addItem(port.name)

    #定时器读取串口信息
    def recvSerial(self):
        line = self.serial_.read_all().decode("utf-8")
        if line:
            self.serial_recv = sRecvFormat(self.main_ui.recv_msg,self.serial_recv,line,self.ports[0].name)
        if not self.serial_.isOpen():
            self.serial_tim.stop()

    def openSerial(self):
        # 打开窗口传参
        try:
            self.serial_ = cvserial.openPort(
                self.ports[0].name,
                int(self.main_ui.baud_rate.currentText()),
                self.main_ui.data_bit.currentText(),
                self.main_ui.parity_bit.currentText(),
                self.main_ui.stop_bit.currentText(),
                self.main_ui.contrl_bit.currentText(),
                self.main_ui.dtr.isChecked(),
                self.main_ui.rst.isChecked()
            )
            self.serial_tim.start()
        except:
            self.tcpline=tcpFormat(self.main_ui.recv_msg,self.tcpline,"打开失败，请先选择串口号.")
            return
        if self.serial_.isOpen():
            self.main_ui.open_com.setEnabled(False)
            self.main_ui.close_com.setEnabled(True)
            Line(self.cmdline, "SERIAL", "打开串口成功!")
            self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, "打开串口成功.")
            self.serial_state.setStyleSheet("color:rgb(0,255,0);")
            self.serial_state.setText("串口已打开")
        else:
            self.main_ui.open_com.setEnabled(True)
            self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, "打开串口失败.")

    def closeSerial(self):
        self.serial_.close()
        if not self.serial_.isOpen():
            Line(self.cmdline, "SERIAL", "关闭串口成功.")
            self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, "关闭串口成功.")
            self.main_ui.open_com.setEnabled(True)
            self.main_ui.close_com.setEnabled(False)
            self.serial_state.setStyleSheet("color:rgb(255,0,0);")
            self.serial_state.setText("串口已关闭.")

    def comSend(self):
        send_msg = self.main_ui.send_msg.toPlainText()
        if self.serial_ != None:
            # HEX发送
            if self.main_ui.hex_send.isChecked() and send_msg:
                send_msg_hex = send_msg.strip()
                hex_list = []

                try:
                    for hex in send_msg_hex.split(" "):
                        hex_list.append(int(hex, 16))
                    # 检测是否发送新行
                    if self.main_ui.send_new.isChecked():
                        hex_list.append("\r\n")
                        self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline,
                                  f"发送新行.")

                    send_msg_hex = bytes(hex_list)
                    #检测是否需要定时发送
                    if self.main_ui.timing.isChecked():
                        self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline,
                                  f"定时发送模式.")
                        self.timer_send_msg = send_msg_hex
                        self.dataSendTimer()
                        return
                    #普通发送-发送一次
                    self.serial_.write(send_msg_hex)
                    self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, f"'{send_msg_hex}' 发送成功.")
                    # 设置串口接收发送的数据量
                    self.TX += len(send_msg_hex)
                    self.rxtx.setText(f"RX:{str(self.RX)} bytes TX:{str(self.TX)} bytes")
                    # Line(self.cmdline, "SERIAL", "'" + str(send_msg_hex) + "'" + "发送成功")
                    self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, f"'{send_msg_hex} size:{len(send_msg_hex)}' 发送成功.")
                except:
                    self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, "十六进制数据转换错误!\n请以空格分隔:1E FF 2D.",color="rgb(255,0,0)")
                    # QMessageBox.critical(self, "错误", "十六进制数据转换错误!\n请以空格分隔:1E FF 2D")
            # 字符发送
            elif not self.main_ui.hex_send.isChecked() and send_msg:
                try:
                    # 检测是否发送新行
                    if self.main_ui.send_new.isChecked():
                        send_msg += "\r\n"
                        self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline,
                                  f"发送新行.")
                    send_msg = (send_msg).encode('utf-8')
                    # 检测是否需要定时发送
                    if self.main_ui.timing.isChecked():
                        self.timer_send_msg = send_msg
                        self.dataSendTimer()
                        return
                    # 普通发送-发送一次
                    self.serial_.write(send_msg)
                    self.TX += len(send_msg)
                    self.rxtx.setText(f"RX:{str(self.RX)} bytes TX:{str(self.TX)} bytes")
                    # Line(self.cmdline, "SERIAL", "'" + str(send_msg) + "'" + "发送成功")
                    self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, f"'{send_msg} size:{len(send_msg)} bytes' 发送成功.")
                except:
                    self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, "未知错误，请检测基本设置.",color="rgb(255,0,0)")
        else:
            self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, "我知道你很忙，但是请先打开串口.",color="rgb(255,0,0)")

    def dataSendTimer(self):
        try:
            if 1 <= int(self.main_ui.how_times.text()) <= 20000:  # 定时时间1ms~30s内
                self.timer_send.setInterval(int(self.main_ui.how_times.text()))
                self.timer_send.start()
                self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, f"已设置定时发送:{int(self.main_ui.how_times.text())}ms/次.")
            else:
                self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, f"请确保周期在1~20000ms内.", color="rgb(255,0,0)")
        except:
            self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, f"数值类型不正确，请确保为整形.",color="rgb(255,0,0)")

    def sendBytime(self):
        self.serial_.write(self.timer_send_msg)
        self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, f"'{timer_send_msg} size:{len(timer_send_msg)}' 发送成功.")
        if not self.main_ui.timing.isChecked():
            self.timer_send.stop()
            self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, f"定时发送结束.")

    def clearSend(self):
        self.main_ui.send_msg.setText("")

    def clearRecv(self):
        self.main_ui.recv_msg.setText("")

    def saveLog(self):
        log_path = QFileDialog.getSaveFileName(self, '保存文件', 'tcp_log', 'HTML files (*.html)')[0]
        if log_path:
            with open(log_path, "w") as fp:
                fp.write(self.tcpline)
            self.tcpline=tcpFormat(self.main_ui.recv_msg, self.tcpline, "导出成功到: " + log_path)
            Line(self.cmdline, "OUT", "导出成功到: " + log_path)

    def saveSend(self):
        pass

    def loadLog(self):
        pass

    '''退出程序，释放资源'''

    def closeEvent(self, event):
        if QMessageBox.question(self, "退出", "数据可能丢失, 确定关闭当前窗口?", QMessageBox.Yes,
                                QMessageBox.No) == QMessageBox.Yes:
            event.accept()
            try:
                self.cv_proc.kill()
                self.tcp_proc.kill()
                self.image_cv_proc.kill()
            except:
                pass
            try:
                self.cube3d_proc.kill()
            except:
                pass
        else:
            event.ignore()
            Line(self.cmdline, "GLOBAL", "取消退出.")

    def keyPressEvent(self, event):
        if str(event.key()) in self.keys.keys():
            self._3dcubeangle.append(self.keys[str(event.key())])

    def mousePressEvent(self, event):
        pass


'''主函数'''
if __name__ == '__main__':
    multiprocessing.freeze_support()

    app = main_ui.QApplication(sys.argv)
    window = MainWindow()
    window.show()

    sys.exit(app.exec_())
