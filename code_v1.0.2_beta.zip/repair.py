
import os
import datetime
import json

help_ = "CBsolver v1.0.0 @KONG\n"\
"这是 'CBsolver v1.0.0' 的帮助文档，希望能够帮到你！\n"\
"你好！\n"\
"...\n"\
"2022年12月23日 结\n"\
"This is CBsolver help document!\n"\
"hello!\n"\
"...\n"\
"End on December 23, 2022\n"\

update_ = "--version #1.0.2\n"\
"--other   #1.增加了魔方3D动画演示,丰富了功能\n"\
"          #2.增加应用内嵌串口调试助手\n"\
"          #3.优化了软件性能\n"\

values_ = {
  "keys": {
          "87": "UP",
          "83": "DOWN",
          "65": "LEFT",
          "68": "RIGHT",
          "81": "LEFTUP",
          "69": "RIGHTUP",
          "90": "LEFTDOWN",
          "88": "RIGHTDOWN",
          "32": "RESET"
  },
  "solve_dict": {
          "U": "blue 顺时针转90°",
          "L": "red 顺时针转90°",
          "F": "yellow 顺时针转90°",
          "D": "green 顺时针转90°",
          "R": "orange 顺时针转90°",
          "B": "white 顺时针转90°",

          "U'": "blue 逆时针转90°",
          "L'": "red 逆时针转90°",
          "F'": "yellow 逆时针转90°",
          "D'": "green 逆时针转90°",
          "R'": "orange 逆时针转90°",
          "B'": "white 逆时针转90°",

          "U2": "blue 顺时针转180°",
          "L2": "red 顺时针转180°",
          "F2": "yellow 顺时针转180°",
          "D2": "green 顺时针转180°",
          "R2": "orange 顺时针转180°",
          "B2": "white 顺时针转180°",

          "U2'": "blue 逆时针转180°",
          "L2'": "red 逆时针转180°",
          "F2'": "yellow 逆时针转180°",
          "D2'": "green 逆时针转180°",
          "R2'": "orange 逆时针转180°",
          "B2'": "white 逆时针转180°"
  },
  "color_dict": {
          "blue"   : "U",
          "red"    : "L",
          "yellow" : "F",
          "green"  : "D",
          "orange" : "R",
          "white"  : "B"
  },
  "step_motor": {

  }
}

settings_ = {
  "view": 1,
  "version": "1.0.2"
}

def sysInit():
    #检测文件夹及文件是否存在
    if not os.path.exists("./color/color.model"):
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 颜色识别模型(color.model)不存在或者路径错误，请联系组织者解决(QQ:1043886331)或更改路径为:./color/color.model")
    else:
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 颜色识别模型(color.model)无误")
    if not os.path.exists("./file/help.cbs"):
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 帮助文档(help.cbs)丢失，即将为您修复.")
        with open("./file/help.cbs","w",encoding="utf-8") as fp:
            fp.write(help_)
            print(f"[{current}] 帮助文档(help.cbs)修复成功.")
    else:
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 帮助文档(help.cbs)无误")
    if not os.path.exists("./ini/setting.cbs"):
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 初始化信息(setting.cbs)丢失，您将丢失设置信息.")

        with open("./ini/setting.cbs","w",encoding="utf-8") as fp:
            json.dump(settings_)
            fp.write(settings_)
            print(f"[{current}] 初始化信息(setting.cbs)修复成功.")
    else:
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 初始化信息(setting.cbs)无误.")
    if not os.path.exists("./ini/update.cbs"):
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 更新文档(update.cbs)文档丢失，即将为您修复.")

        with open("./ini/update.cbs","w",encoding="utf-8") as fp:
            fp.write(update_)
            print(f"[{current}] 更新文档(update.cbs)修复成功.")
    else:
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 更新文档(update.cbs)无误.")
    if not os.path.exists("./ini/values.cbs"):
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 初始化文档(values.cbs)丢失，即将为您修复.")

        with open("./ini/values.cbs","w",encoding="utf-8") as fp:
            json.dump(values_)
            fp.write(values_)
            print(f"[{current}] 初始化文档(values.cbs)修复成功.")

    else:
        current = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{current}] 初始化文档(values.cbs)无误.")

if __name__ == '__main__':
    try:
        sysInit()
        os.system("pause")
    except:
        print("请将该可执行文件放在根目录.")
        os.system("pause")