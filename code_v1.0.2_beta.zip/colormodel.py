
import joblib
import datetime
import numpy as np


model_path = "./color/color.model"

clf = joblib.load(model_path) # 加载模型


def img2vector(img):
    img_arr = np.array(img)
    img_normlization = img_arr /255
    img_arr2 = np.reshape(img_normlization, (1 ,-1))
    return img_arr2

def getColor(obj_):
    img_arr = img2vector(obj_)
    retcolor = clf.predict(img_arr)

    return retcolor[0]