
import socket
import datetime
from formatcmd import Line


def createTcp(ip,port,send,recv):
    try:
        if ip == None:
            ip = socket.gethostbyname(socket.gethostname())
        # 创建socket
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # 绑定
        server.bind((ip,int(port)))
        Line(recv,"TCP","已创建TCP服务器("+ip+":"+str(port)+"), 等待连接...")
        # 使用socket创建的套接字默认的属性是主动的，使用listen将其变为被动的，这样就可以接收别人的链接了
        server.listen(128)
        # clientAddr 是元组（ip，端口）
        client, addr = server.accept()
        Line(recv, "TCP", "已连接")
        while True:
            if len(send)>0:
                if send[0]=="__closetcp__":
                    send.pop(0)
                    return
                # 发送一些数据到客户端
                client.send(str(send[0]).encode('GBK'))
                Line(recv, "TCP", "\""+str(send[0])+"\" 发送成功!")
                send.pop(0)
    except:
        Line(recv, "TCPSERVER", "TCP服务器端创建失败，请更换端口重试！", color="rgb(255,0,0)")
        return


