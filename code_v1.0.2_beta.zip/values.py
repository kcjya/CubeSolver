
import json

def valuesInit():
    with open("ini/values.cbs", "r", encoding="utf-8") as fp:
        values = json.load(fp)

    return values.get("keys"),values.get("solve_dict"),values.get("color_dict"),values.get("step_motor"),values.get("color_list")
