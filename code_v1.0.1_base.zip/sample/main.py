
#添加各种包
from package import*


#全局颜色字典
color_dict={
    "blue"   : "U",
    "red"    : "L",
    "yellow" : "F",
    "green"  : "D",
    "orange" : "R",
    "white"  : "B"
}

#全局颜色字典
solve_dict={
    "U": "blue 顺时针转90°",
    "L": "red 顺时针转90°",
    "F": "yellow 顺时针转90°",
    "D": "green 顺时针转90°",
    "R": "orange 顺时针转90°",
    "B": "white 顺时针转90°",

    "U'": "blue 逆时针转90°",
    "L'": "red 逆时针转90°",
    "F'": "yellow 逆时针转90°",
    "D'": "green 逆时针转90°",
    "R'": "orange 逆时针转90°",
    "B'": "white 逆时针转90°",

    "U2": "blue 顺时针转180°",
    "L2": "red 顺时针转180°",
    "F2": "yellow 顺时针转180°",
    "D2": "green 顺时针转180°",
    "R2": "orange 顺时针转180°",
    "B2": "white 顺时针转180°",

    "U2'": "blue 逆时针转180°",
    "L2'": "red 逆时针转180°",
    "F2'": "yellow 逆时针转180°",
    "D2'": "green 逆时针转180°",
    "R2'": "orange 逆时针转180°",
    "B2'": "white 逆时针转180°",
}

# send_data=tcp.send_data



'''
    作用：主窗口类
    继承自：QMainWindow
'''
class MainWindow(main_ui.QMainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.main_ui = main_ui.Ui_MainWindow()
        self.main_ui.setupUi(self)

        self.resize(1500, 900)
        self.setWindowTitle("CBSolver by KONG")
        self.main_ui.video.resize(450, 340)
        # self.main_ui.video.move(400, 0)


        self.pop_up_camera = popcamera.PopCamera("相机上视图")
        self.pop_down_camera = popcamera.PopCamera("相机下视图")
        self.pop_left_camera = popcamera.PopCamera("相机左视图")
        self.pop_right_camera = popcamera.PopCamera("相机右视图")

        #软件个窗口的初始化设置
        self.windowsInit()
        #相关定时器初始化
        self.timersInit()
        #相关按钮初始化
        self.buttonsInit()

        #全局变量
        self.lines = ""

        # 启动一个线程，等待结束
        self.manager = multiprocessing.Manager()
        # 线程数据共享字典
        self.video_data = self.manager.list()
        self.readcube_rest = self.manager.dict()
        self.cmdline =  self.manager.list()
        self.sendline = self.manager.list()
        #图片处理CV
        self.returnImages = self.manager.dict()
        self.returnresults = self.manager.dict()

        self.cv_proc = multiprocessing.Process(target=opencv.cv_1, args=(self.video_data,self.readcube_rest,self.cmdline,))
        self.cv_proc.start()


        copyright = QLabel("CBSolver v1.0.0  @KONG 2023")
        self.main_ui.statusbar.addPermanentWidget(copyright)

    '''
        作用：软件各个窗口特征的初始化
        参数：无
        返回值：无
    '''
    def windowsInit(self):
        self.main_ui.app_setting_win.close()
        self.main_ui.about_win.close()

        self.main_ui.camera_view_win.setMinimumWidth(450)
        self.main_ui.center.resize(self.width(),self.height())

        self.main_ui.console_win_view.setMinimumHeight(280)

    '''
        作用：软件各个定时器事件的初始化
        参数：无
        返回值：无
    '''
    def timersInit(self):
        #摄像机机位1试试刷新
        self.videotim_1 = QTimer(self)
        self.videotim_1.setInterval(1)
        self.videotim_1.timeout.connect(self.showVideo_1)
        self.videotim_1.start()
        # 实时获取console
        self.console_tim = QTimer(self)
        self.console_tim.setInterval(100)
        self.console_tim.timeout.connect(self.updataConsole)
        self.console_tim.start()
        #实时获取image cv处理的结果
        self.imagecv_tim = QTimer(self)
        self.imagecv_tim.setInterval(100)
        self.imagecv_tim.timeout.connect(self.updataImagecvResult)
        # 实时发送信息
        # self.send_tim = QTimer(self)
        # self.send_tim.setInterval(100)
        # self.send_tim.timeout.connect(self.updataSenddata)
    '''
        作用：软件各个按钮事件的初始化
        参数：无
        返回值：无
        注意：在程序一开始的时候调用
    '''
    def buttonsInit(self):
        #弹出个相机大窗口
        self.main_ui.top_camera.clicked.connect(self.pop_up_camera.show)
        self.main_ui.down_camera.clicked.connect(self.pop_down_camera.show)
        self.main_ui.left_camera.clicked.connect(self.pop_left_camera.show)
        self.main_ui.right_camera.clicked.connect(self.pop_right_camera.show)
        #导出控制栏历史信息
        self.main_ui.out_console.triggered.connect(self.outConsole)
        #识别一次颜色
        self.main_ui.read_once.clicked.connect(self.readColor)
        #关闭摄像头
        self.main_ui.close_camera.clicked.connect(self.videotim_1.stop)

        #toolbox 按钮初始化
        # 退出程序
        self.main_ui.close.triggered.connect(self.Close)
        self.main_ui.close_win.triggered.connect(self.Close)
        self.main_ui.quit_app.triggered.connect(self.Close)
        self.main_ui.import_image.triggered.connect(self.importImage)       #导入图片
        self.main_ui.save_cube_ex.triggered.connect(self.saveCubeex)        #保存魔方展开图
        #导入或者保存相关文件
        self.main_ui.camera_show.triggered.connect(self.cameraWinShow)  # 导入图片
        self.main_ui.console_show.triggered.connect(self.consoleWinShow)  # 保存魔方展开图
        #弹出设置窗口
        self.main_ui.global_setting.triggered.connect(self.appSettingwin)  # 打开设置窗口
        self.main_ui.app_setting.triggered.connect(self.appSettingwin)
        self.main_ui.seral_setting.triggered.connect(self.appSettingwin)
        self.main_ui.tcp_setting.triggered.connect(self.appSettingwin)
        #弹出帮助窗口
        self.main_ui.help_text.triggered.connect(self.aboutWin)
        self.main_ui.about.triggered.connect(self.aboutWin)
        #回车发送
        self.main_ui.send.returnPressed.connect(self.sendData)
        #发送解决方案
        self.main_ui.send_solve.clicked.connect(self.sendSolve)

        #下载帮助文档
        self.main_ui.download_help.clicked.connect(self.downloadHelp)
        #创建tcp服务器
        self.main_ui.createtcp.clicked.connect(self.createTcp)


    def createTcp(self):
        ip = self.main_ui.ip.text()
        port = self.main_ui.port.text()
        # 创建TCP实例
        self.tcp_proc = multiprocessing.Process(target=tcp.createTcp,args=(ip, port,self.sendline ,self.cmdline,))
        self.tcp_proc.start()


    # def updataSenddata(self):
    #     send_data.append()

    def readColor(self):
        self.videotim_1.start()
        if self.cv_proc.is_alive():
            self.cv_proc.kill()
        else:
            pass
        self.cv_proc.start()

    '''
        作用：下载帮助文档到本地
        参数：无
        返回值：无
    '''
    def downloadHelp(self):
        help = "欢迎使用魔方助手"
        out_path = QFileDialog.getSaveFileName(self, '保存文件', 'help', 'TXT files (*.txt)')[0]
        if out_path:
            with open(out_path, "w") as fp:

                fp.write(help)
    '''作用：显示设置的窗口'''
    def appSettingwin(self):
        self.main_ui.about_win.close()
        self.main_ui.app_setting_win.setMinimumWidth(450)
        self.main_ui.app_setting_win.show()
    '''作用：显示关于的窗口'''
    def aboutWin(self):
        self.main_ui.app_setting_win.close()
        self.main_ui.about_win.setMinimumWidth(450)
        self.main_ui.about_win.show()

    '''退出程序，释放资源'''
    def Close(self):
        try:
            self.cv_proc.kill()
            self.tcp_proc.kill()
            self.image_cv_proc.kill()
        except:
            pass
        self.close()
    def closeEvent(self, event):
        if QMessageBox.question(self,"退出","数据可能丢失, 确定关闭当前窗口?",QMessageBox.Yes, QMessageBox.No) == QMessageBox.Yes:
            event.accept()
            self.Close()
        else:
            event.ignore()

    '''
        作用：是否相机视角窗口
    '''
    def cameraWinShow(self,check):
        if check:
            self.main_ui.camera_view_win.show()
        else:
            self.main_ui.camera_view_win.close()
    '''
        作用：是否显示控制台
    '''
    def consoleWinShow(self,check):
        if check:
            self.main_ui.console_win_view.show()
        else:
            self.main_ui.console_win_view.close()

    '''
        作用：保存到本地从opencv中读取的6面魔方的信息
        参数：无
        返回值：无
        注意：本身是一个按钮的回调函数
    '''
    def saveCubeex(self):
        out_path = QFileDialog.getSaveFileName(self, '保存文件', 'cube_expand', 'Image files (*.png);; Image files (*.jpg)')[0]
        if out_path:
            with open(out_path,"wb") as fp:
                fp.write("")

    '''
        作用：从本地导入6张图片，从图片解算出魔方的揭发返回给用户
        参数：无
        返回值：无
        注意：本身是一个按钮的回调函数
    '''
    def importImage(self):
        t=self.main_ui
        self.result_images = [t.read_image_1,t.read_image_2,t.read_image_3,t.read_image_4,t.read_image_5,t.read_image_6]
        images = QFileDialog.getOpenFileNames(self, "选择图片文件")[0]  # 选择目录，返回选中的路径
        if len(images)==6:
            self.returnImages.clear()
            self.import_images = images
            self.image_cv_proc = multiprocessing.Process(target=opencv.image_cv,args=(self.import_images,self.returnImages ,self.returnresults,self.cmdline,))
            self.image_cv_proc.start()
            self.imagecv_tim.start()
        else:
            current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "] "
            self.cmdline.append(current+"管理员: 导入图片数量不为6张, 任务已取消!")


    '''
         作用：更新图片识别的结果
         参数：无
         返回值：无
         注意：本身是一个定时器的回调函数，识别结束，定时器自动关闭
     '''
    def updataImagecvResult(self):
        finish = 0
        colors = ["blue","red","yellow","green","orange","white"]
        for recolor in self.result_images:
            try:
                index = self.result_images.index(recolor)
                recolor.setStyleSheet("border-image: url(" + self.returnImages.get(
                    colors[index]) + ");background-color: rgba(255, 255, 255, 0);color: rgb(0, 0, 0);")

                finish+=1
                print(finish)
            except:
                pass
        #如果finish次数大于6，说明完成读取
        if finish>=6:
            self.imagecv_tim.stop()
            self.image_cv_proc.kill()
            current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "] "
            self.cmdline.append(current+"IMAGECV(SUCCEED):\"识别结果:")
            self.cmdline.append("\t\"(blue)中心块:\"" + str(self.returnresults.get("blue")))
            self.cmdline.append("\t\"(red)中心块:\"" + str(self.returnresults.get("red")))
            self.cmdline.append("\t\"(yellow)中心块:\"" + str(self.returnresults.get("yellow")))
            self.cmdline.append("\t\"(green)中心块:\"" + str(self.returnresults.get("green")))
            self.cmdline.append("\t\"(orange)中心块:\"" + str(self.returnresults.get("orange")))
            self.cmdline.append("\t\"(white)中心块:\"" + str(self.returnresults.get("white")))
            #获取魔方的字符串
            cs = self.getCubeString()
            self.main_ui.cube_string.setText(cs)
            self.cmdline.append("管理员:\"魔方字块-\"" + cs)
            self.cube_solve = cube.cubeSolve(cs)
            if self.cube_solve:
                current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "]"
                self.main_ui.solve_string.setText(self.cube_solve)
                self.cmdline.append(current+" SUCCEED:\"魔方解决方案为-\"" + self.cube_solve)
                self.cmdline.append(current+" SUCCEED:\"魔方最终还原步骤为\"")
                solve_list = self.cube_solve.split(" ")
                for str_ in solve_list:
                    self.cmdline.append("\t" + solve_dict.get(str_))
                current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "]"
                self.cmdline.append(current+" SUCCEED:\"(共:"+str(len(solve_list))+"步)\n")
            else:
                current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "]"
                self.cmdline.append(current+" ERROR:\"创建解决方案失败!\"")

    '''
         作用：获取魔方的字段
         参数：无
         返回值：无
     '''
    def getCubeString(self):
        cube_string = ""
        colors = ["blue", "orange", "yellow", "green", "red", "white"]
        for center_color in colors:
            for color in self.returnresults.get(center_color):
                cube_string += color_dict.get(color)

        return cube_string

    '''
        作用：定时从opencv.py文档中获取已经完成的命令
        参数：无
        返回值：无
        注意：本身是一个定时器的回调函数
    '''
    def updataConsole(self):
        # print(opencv.cmd.getValue(0))
        try:
            self.lines += self.cmdline[0]+"\n"
            self.main_ui.line.setText(self.lines)
            self.main_ui.line.moveCursor(QTextCursor.End)
            self.cmdline.pop(0)
        except:
            pass

    '''
        作用：将软件控制台的类容输出为txt文档以供参考
        参数：无
        返回值：无
        注意：本身是一个按钮的回调函数
    '''
    def outConsole(self):
        out_path = QFileDialog.getSaveFileName(self, '保存文件', 'console', 'TXT files (*.txt)')[0]
        if out_path:
            with open(out_path, "w") as fp:
                fp.write(self.lines)

    '''
        作用：在软件界面实时更新Label对象，让其成为视频
        参数：无
        返回值：无
        注意：本身是一个定时器的回调函数
    '''
    def showVideo_1(self):
        if len(self.video_data) > 0:
            video = self.cvimg_to_qtimg(self.video_data[0], self.main_ui.video.width(), self.main_ui.video.height())
            video_pop = self.cvimg_to_qtimg(self.video_data[0], self.pop_up_camera.popcamera_ui.video.width(), self.pop_up_camera.popcamera_ui.video.height())
            self.main_ui.video.setPixmap(video)
            self.main_ui.video_2.setPixmap(video)
            self.main_ui.video_3.setPixmap(video)
            self.main_ui.video_4.setPixmap(video)
            #弹出的相机视角更新程序
            if self.pop_up_camera.isVisible():
                self.pop_up_camera.setVideo(video_pop)
            if self.pop_down_camera.isVisible():
                self.pop_down_camera.setVideo(video_pop)
            if self.pop_left_camera.isVisible():
                self.pop_left_camera.setVideo(video_pop)
            if self.pop_right_camera.isVisible():
                self.pop_right_camera.setVideo(video_pop)

            self.video_data.pop(0)
        else:
            pass

    '''
    作用：将opencv读取的帧转换为qt的QPixmap类型
    参数：(frame)opencv的对象，(width, height)图片的大小
    返回值：qt类型QPixmap
    '''
    def cvimg_to_qtimg(self, frame, width, height):
        # 显示图像
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # 格式转换
        img = QImage(frame.data, frame.shape[1], frame.shape[0], frame.shape[1] * 3, QImage.Format_RGB888)
        pix = QPixmap(img).scaled(width, height)

        return pix

    def sendData(self):
        send_data = self.main_ui.send.text()
        if send_data:
            self.sendline.append(send_data)
            self.main_ui.send.clear()
        else:
            current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "]"
            self.cmdline.append(current+" WARNING: 内容不能为空!")

    def sendSolve(self):
        try:
            self.sendline.append(self.cube_solve)
        except:
            current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "]"
            self.cmdline.append(current+" WARNING: 还没有解决方案!")


    def keyPressEvent(self,event):
        pass

    # def updataSenddata(self):



'''主函数'''
if __name__ == '__main__':
    multiprocessing.freeze_support()

    app = main_ui.QApplication(sys.argv)
    window = MainWindow()
    window.show()

    sys.exit(app.exec_())
