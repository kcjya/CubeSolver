import socket

client = socket.socket()
client.connect(("192.168.137.1", 7788))

while True:
    data = client.recv(1024)
    print(data.decode("GBK"))


client.close()