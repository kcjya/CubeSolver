
import numpy as np
import os
import joblib
import matplotlib.pyplot as plt
import cv2

model_path = r'C:\Users\ChuiJiang Kong\Desktop\color\color.model'
img_path = r"C:\Users\ChuiJiang Kong\Desktop\test_color"

clf = joblib.load(model_path) # 加载模型

def img2vector(img):

    img_arr = np.array(img)
    img_normlization = img_arr /255
    img_arr2 = np.reshape(img_normlization, (1 ,-1))
    return img_arr2

i = 1
for file in os.listdir(img_path):

    filepath = os.path.join(img_path, file)
    img = cv2.imread(filepath)

    img2arr = img2vector(img)
    preResult = clf.predict(img2arr)

    img = cv2.cvtColor(img ,cv2.COLOR_BGR2RGB)
    plt.subplot(3 ,3 ,i)
    plt.imshow(img)
    plt.title(preResult)
    i += 1
    print(preResult)

plt.show()