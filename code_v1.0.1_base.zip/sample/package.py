

'''pyside2包'''
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
from PySide2.QtMultimedia import *

'''系统包'''
import os
import cv2
import sys
import datetime
import socketserver
import multiprocessing


'''自定义包'''
import tcp
import cube
import opencv
import console
import main_ui
import popcamera
