# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_ui.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import res_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1244, 817)
        icon = QIcon()
        icon.addFile(u":/res/icon/logo.png", QSize(), QIcon.Normal, QIcon.Off)
        MainWindow.setWindowIcon(icon)
        self.import_image = QAction(MainWindow)
        self.import_image.setObjectName(u"import_image")
        self.quit_app = QAction(MainWindow)
        self.quit_app.setObjectName(u"quit_app")
        self.save_cube_ex = QAction(MainWindow)
        self.save_cube_ex.setObjectName(u"save_cube_ex")
        self.close_win = QAction(MainWindow)
        self.close_win.setObjectName(u"close_win")
        self.import_form = QAction(MainWindow)
        self.import_form.setObjectName(u"import_form")
        self.import_way = QAction(MainWindow)
        self.import_way.setObjectName(u"import_way")
        self.app_setting = QAction(MainWindow)
        self.app_setting.setObjectName(u"app_setting")
        self.seral_setting = QAction(MainWindow)
        self.seral_setting.setObjectName(u"seral_setting")
        self.tcp_setting = QAction(MainWindow)
        self.tcp_setting.setObjectName(u"tcp_setting")
        self.about = QAction(MainWindow)
        self.about.setObjectName(u"about")
        self.help_text = QAction(MainWindow)
        self.help_text.setObjectName(u"help_text")
        self.min_show = QAction(MainWindow)
        self.min_show.setObjectName(u"min_show")
        self.max_show = QAction(MainWindow)
        self.max_show.setObjectName(u"max_show")
        self.close = QAction(MainWindow)
        self.close.setObjectName(u"close")
        self.normal = QAction(MainWindow)
        self.normal.setObjectName(u"normal")
        self.camera_show = QAction(MainWindow)
        self.camera_show.setObjectName(u"camera_show")
        self.camera_show.setCheckable(True)
        self.camera_show.setChecked(True)
        self.console_show = QAction(MainWindow)
        self.console_show.setObjectName(u"console_show")
        self.console_show.setCheckable(True)
        self.console_show.setChecked(True)
        self.global_setting = QAction(MainWindow)
        self.global_setting.setObjectName(u"global_setting")
        self.out_console = QAction(MainWindow)
        self.out_console.setObjectName(u"out_console")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayout_4 = QGridLayout(self.centralwidget)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.center = QTabWidget(self.centralwidget)
        self.center.setObjectName(u"center")
        font = QFont()
        font.setFamily(u"\u5fae\u8f6f\u96c5\u9ed1")
        self.center.setFont(font)
        self.work = QWidget()
        self.work.setObjectName(u"work")
        self.verticalLayout = QVBoxLayout(self.work)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.read_image_1 = QLabel(self.work)
        self.read_image_1.setObjectName(u"read_image_1")
        font1 = QFont()
        font1.setFamily(u"\u5fae\u8f6f\u96c5\u9ed1")
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setWeight(75)
        self.read_image_1.setFont(font1)
        self.read_image_1.setStyleSheet(u"border-image: url(:/res/icon/logo.png);\n"
"background-color: rgba(255, 255, 255, 0);\n"
"color: rgb(0, 0, 0);")
        self.read_image_1.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.horizontalLayout_2.addWidget(self.read_image_1)

        self.read_image_2 = QLabel(self.work)
        self.read_image_2.setObjectName(u"read_image_2")
        self.read_image_2.setFont(font1)
        self.read_image_2.setStyleSheet(u"border-image: url(:/res/icon/logo.png);\n"
"background-color: rgba(255, 255, 255, 0);\n"
"color: rgb(0, 0, 0);")
        self.read_image_2.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.horizontalLayout_2.addWidget(self.read_image_2)

        self.read_image_3 = QLabel(self.work)
        self.read_image_3.setObjectName(u"read_image_3")
        self.read_image_3.setFont(font1)
        self.read_image_3.setStyleSheet(u"border-image: url(:/res/icon/logo.png);\n"
"background-color: rgba(255, 255, 255, 0);\n"
"color: rgb(0, 0, 0);")
        self.read_image_3.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.horizontalLayout_2.addWidget(self.read_image_3)

        self.read_image_4 = QLabel(self.work)
        self.read_image_4.setObjectName(u"read_image_4")
        self.read_image_4.setFont(font1)
        self.read_image_4.setStyleSheet(u"border-image: url(:/res/icon/logo.png);\n"
"background-color: rgba(255, 255, 255, 0);\n"
"color: rgb(0, 0, 0);")
        self.read_image_4.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.horizontalLayout_2.addWidget(self.read_image_4)

        self.read_image_5 = QLabel(self.work)
        self.read_image_5.setObjectName(u"read_image_5")
        self.read_image_5.setFont(font1)
        self.read_image_5.setStyleSheet(u"border-image: url(:/res/icon/logo.png);\n"
"background-color: rgba(255, 255, 255, 0);\n"
"color: rgb(0, 0, 0);")
        self.read_image_5.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.horizontalLayout_2.addWidget(self.read_image_5)

        self.read_image_6 = QLabel(self.work)
        self.read_image_6.setObjectName(u"read_image_6")
        self.read_image_6.setFont(font1)
        self.read_image_6.setStyleSheet(u"border-image: url(:/res/icon/logo.png);\n"
"background-color: rgba(255, 255, 255, 0);\n"
"color: rgb(0, 0, 0);")
        self.read_image_6.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.horizontalLayout_2.addWidget(self.read_image_6)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.line_3 = QFrame(self.work)
        self.line_3.setObjectName(u"line_3")
        self.line_3.setFrameShape(QFrame.HLine)
        self.line_3.setFrameShadow(QFrame.Sunken)

        self.verticalLayout.addWidget(self.line_3)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.frame_2 = QFrame(self.work)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.label = QLabel(self.frame_2)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(0, 22, 81, 16))
        font2 = QFont()
        font2.setFamily(u"\u5fae\u8f6f\u96c5\u9ed1")
        font2.setPointSize(9)
        self.label.setFont(font2)
        self.label.setAlignment(Qt.AlignCenter)
        self.label_3 = QLabel(self.frame_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(0, 0, 81, 16))
        self.label_3.setFont(font2)
        self.label_3.setAlignment(Qt.AlignCenter)
        self.cube_string = QLineEdit(self.frame_2)
        self.cube_string.setObjectName(u"cube_string")
        self.cube_string.setGeometry(QRect(70, -2, 921, 21))
        self.cube_string.setFont(font1)
        self.cube_string.setStyleSheet(u"border:none;\n"
"background-color: rgba(255, 255, 255, 0);")
        self.solve_string = QLineEdit(self.frame_2)
        self.solve_string.setObjectName(u"solve_string")
        self.solve_string.setGeometry(QRect(70, 22, 921, 21))
        self.solve_string.setFont(font1)
        self.solve_string.setStyleSheet(u"border:none;\n"
"background-color: rgba(255, 255, 255, 0);")

        self.horizontalLayout_3.addWidget(self.frame_2)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.line_2 = QFrame(self.work)
        self.line_2.setObjectName(u"line_2")
        self.line_2.setFrameShape(QFrame.HLine)
        self.line_2.setFrameShadow(QFrame.Sunken)

        self.verticalLayout.addWidget(self.line_2)

        self.gridLayout_6 = QGridLayout()
        self.gridLayout_6.setObjectName(u"gridLayout_6")
        self.frame = QFrame(self.work)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.send_solve = QPushButton(self.frame)
        self.send_solve.setObjectName(u"send_solve")
        self.send_solve.setGeometry(QRect(860, 100, 121, 31))
        self.send_mode = QComboBox(self.frame)
        self.send_mode.addItem("")
        self.send_mode.addItem("")
        self.send_mode.setObjectName(u"send_mode")
        self.send_mode.setGeometry(QRect(860, 0, 121, 31))

        self.gridLayout_6.addWidget(self.frame, 0, 0, 1, 1)


        self.verticalLayout.addLayout(self.gridLayout_6)

        self.center.addTab(self.work, "")
        self.widget = QWidget()
        self.widget.setObjectName(u"widget")
        self.center.addTab(self.widget, "")

        self.gridLayout_4.addWidget(self.center, 0, 0, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1244, 26))
        self.menu = QMenu(self.menubar)
        self.menu.setObjectName(u"menu")
        self.menu_2 = QMenu(self.menu)
        self.menu_2.setObjectName(u"menu_2")
        self.menu_S = QMenu(self.menubar)
        self.menu_S.setObjectName(u"menu_S")
        self.menu_3 = QMenu(self.menu_S)
        self.menu_3.setObjectName(u"menu_3")
        self.menu_H = QMenu(self.menubar)
        self.menu_H.setObjectName(u"menu_H")
        self.menu_4 = QMenu(self.menu_H)
        self.menu_4.setObjectName(u"menu_4")
        self.menu_W = QMenu(self.menubar)
        self.menu_W.setObjectName(u"menu_W")
        self.menu_5 = QMenu(self.menubar)
        self.menu_5.setObjectName(u"menu_5")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.console_win_view = QDockWidget(MainWindow)
        self.console_win_view.setObjectName(u"console_win_view")
        self.console_win_view.setFont(font)
        self.console_win_view.setStyleSheet(u"")
        self.dockWidgetContents = QWidget()
        self.dockWidgetContents.setObjectName(u"dockWidgetContents")
        self.verticalLayout_2 = QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.line = QTextBrowser(self.dockWidgetContents)
        self.line.setObjectName(u"line")
        font3 = QFont()
        font3.setFamily(u"\u5fae\u8f6f\u96c5\u9ed1")
        font3.setPointSize(10)
        self.line.setFont(font3)
        self.line.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(85, 255, 127);")
        self.line.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.line.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.verticalLayout_2.addWidget(self.line)

        self.send = QLineEdit(self.dockWidgetContents)
        self.send.setObjectName(u"send")
        self.send.setFont(font)
        self.send.setReadOnly(False)

        self.verticalLayout_2.addWidget(self.send)

        self.console_win_view.setWidget(self.dockWidgetContents)
        MainWindow.addDockWidget(Qt.BottomDockWidgetArea, self.console_win_view)
        self.camera_view_win = QDockWidget(MainWindow)
        self.camera_view_win.setObjectName(u"camera_view_win")
        self.camera_view_win.setFont(font)
        self.dockWidgetContents_2 = QWidget()
        self.dockWidgetContents_2.setObjectName(u"dockWidgetContents_2")
        self.gridLayoutWidget = QWidget(self.dockWidgetContents_2)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(0, 0, 431, 481))
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.left_camera = QPushButton(self.gridLayoutWidget)
        self.left_camera.setObjectName(u"left_camera")

        self.gridLayout.addWidget(self.left_camera, 3, 0, 1, 1)

        self.top_camera = QPushButton(self.gridLayoutWidget)
        self.top_camera.setObjectName(u"top_camera")

        self.gridLayout.addWidget(self.top_camera, 1, 0, 1, 1)

        self.video_2 = QLabel(self.gridLayoutWidget)
        self.video_2.setObjectName(u"video_2")

        self.gridLayout.addWidget(self.video_2, 0, 1, 1, 1)

        self.video_3 = QLabel(self.gridLayoutWidget)
        self.video_3.setObjectName(u"video_3")

        self.gridLayout.addWidget(self.video_3, 2, 0, 1, 1)

        self.video_4 = QLabel(self.gridLayoutWidget)
        self.video_4.setObjectName(u"video_4")

        self.gridLayout.addWidget(self.video_4, 2, 1, 1, 1)

        self.right_camera = QPushButton(self.gridLayoutWidget)
        self.right_camera.setObjectName(u"right_camera")

        self.gridLayout.addWidget(self.right_camera, 3, 1, 1, 1)

        self.video = QLabel(self.gridLayoutWidget)
        self.video.setObjectName(u"video")

        self.gridLayout.addWidget(self.video, 0, 0, 1, 1)

        self.down_camera = QPushButton(self.gridLayoutWidget)
        self.down_camera.setObjectName(u"down_camera")

        self.gridLayout.addWidget(self.down_camera, 1, 1, 1, 1)

        self.read_once = QPushButton(self.gridLayoutWidget)
        self.read_once.setObjectName(u"read_once")

        self.gridLayout.addWidget(self.read_once, 4, 0, 1, 1)

        self.close_camera = QPushButton(self.gridLayoutWidget)
        self.close_camera.setObjectName(u"close_camera")

        self.gridLayout.addWidget(self.close_camera, 4, 1, 1, 1)

        self.camera_view_win.setWidget(self.dockWidgetContents_2)
        MainWindow.addDockWidget(Qt.RightDockWidgetArea, self.camera_view_win)
        self.app_setting_win = QDockWidget(MainWindow)
        self.app_setting_win.setObjectName(u"app_setting_win")
        self.dockWidgetContents_3 = QWidget()
        self.dockWidgetContents_3.setObjectName(u"dockWidgetContents_3")
        self.label_4 = QLabel(self.dockWidgetContents_3)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(10, 10, 72, 15))
        self.label_4.setFont(font)
        self.label_4.setStyleSheet(u"background-color: rgba(255, 255, 255, 0);")
        self.ip = QLineEdit(self.dockWidgetContents_3)
        self.ip.setObjectName(u"ip")
        self.ip.setGeometry(QRect(110, 40, 181, 31))
        self.ip.setFont(font1)
        self.ip.setStyleSheet(u"background-color: rgba(255, 255, 255, 0);\n"
"border:none;")
        self.ip.setAlignment(Qt.AlignCenter)
        self.label_5 = QLabel(self.dockWidgetContents_3)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(30, 40, 72, 31))
        self.label_5.setFont(font)
        self.label_5.setStyleSheet(u"background-color: rgba(255, 255, 255, 0);")
        self.label_6 = QLabel(self.dockWidgetContents_3)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(30, 70, 41, 31))
        self.label_6.setFont(font)
        self.label_6.setStyleSheet(u"background-color: rgba(255, 255, 255, 0);")
        self.port = QLineEdit(self.dockWidgetContents_3)
        self.port.setObjectName(u"port")
        self.port.setGeometry(QRect(110, 70, 181, 31))
        self.port.setFont(font1)
        self.port.setStyleSheet(u"background-color: rgba(255, 255, 255, 0);\n"
"border:none;")
        self.port.setAlignment(Qt.AlignCenter)
        self.createtcp = QPushButton(self.dockWidgetContents_3)
        self.createtcp.setObjectName(u"createtcp")
        self.createtcp.setGeometry(QRect(380, 40, 71, 71))
        self.createtcp.setFont(font)
        self.createtcp.setCursor(QCursor(Qt.PointingHandCursor))
        self.app_setting_win.setWidget(self.dockWidgetContents_3)
        MainWindow.addDockWidget(Qt.LeftDockWidgetArea, self.app_setting_win)
        self.about_win = QDockWidget(MainWindow)
        self.about_win.setObjectName(u"about_win")
        self.dockWidgetContents_5 = QWidget()
        self.dockWidgetContents_5.setObjectName(u"dockWidgetContents_5")
        self.download_help = QPushButton(self.dockWidgetContents_5)
        self.download_help.setObjectName(u"download_help")
        self.download_help.setGeometry(QRect(10, 10, 101, 28))
        self.download_help.setFont(font)
        self.download_help.setCursor(QCursor(Qt.PointingHandCursor))
        self.download_help.setStyleSheet(u"background-color: rgba(255, 255, 255, 0);\n"
"color: rgb(0, 147, 221);")
        self.about_win.setWidget(self.dockWidgetContents_5)
        MainWindow.addDockWidget(Qt.LeftDockWidgetArea, self.about_win)

        self.menubar.addAction(self.menu.menuAction())
        self.menubar.addAction(self.menu_S.menuAction())
        self.menubar.addAction(self.menu_5.menuAction())
        self.menubar.addAction(self.menu_W.menuAction())
        self.menubar.addAction(self.menu_H.menuAction())
        self.menu.addAction(self.import_image)
        self.menu.addAction(self.save_cube_ex)
        self.menu.addAction(self.out_console)
        self.menu.addAction(self.menu_2.menuAction())
        self.menu.addSeparator()
        self.menu.addAction(self.close_win)
        self.menu.addAction(self.quit_app)
        self.menu_2.addAction(self.import_way)
        self.menu_2.addAction(self.import_form)
        self.menu_S.addAction(self.app_setting)
        self.menu_S.addAction(self.menu_3.menuAction())
        self.menu_S.addSeparator()
        self.menu_S.addAction(self.global_setting)
        self.menu_3.addAction(self.seral_setting)
        self.menu_3.addAction(self.tcp_setting)
        self.menu_H.addAction(self.menu_4.menuAction())
        self.menu_H.addSeparator()
        self.menu_H.addAction(self.about)
        self.menu_4.addAction(self.help_text)
        self.menu_W.addAction(self.min_show)
        self.menu_W.addAction(self.max_show)
        self.menu_W.addAction(self.normal)
        self.menu_W.addSeparator()
        self.menu_W.addAction(self.close)
        self.menu_5.addAction(self.camera_show)
        self.menu_5.addAction(self.console_show)

        self.retranslateUi(MainWindow)

        self.center.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.import_image.setText(QCoreApplication.translate("MainWindow", u"\u5bfc\u5165\u56fe\u7247 (O)             Ctrl+O", None))
        self.quit_app.setText(QCoreApplication.translate("MainWindow", u"\u9000\u51fa (Q)                     ESC", None))
        self.save_cube_ex.setText(QCoreApplication.translate("MainWindow", u"\u4fdd\u5b58\u5c55\u5f00\u56fe (S)          Ctrl+S", None))
        self.close_win.setText(QCoreApplication.translate("MainWindow", u"\u5173\u95ed (C)", None))
        self.import_form.setText(QCoreApplication.translate("MainWindow", u"\u67e5\u770b\u5bfc\u5165\u683c\u5f0f", None))
        self.import_way.setText(QCoreApplication.translate("MainWindow", u"\u67e5\u770b\u4f7f\u7528\u65b9\u6cd5", None))
        self.app_setting.setText(QCoreApplication.translate("MainWindow", u"\u8f6f\u4ef6 (R)", None))
        self.seral_setting.setText(QCoreApplication.translate("MainWindow", u"\u4e32\u53e3", None))
        self.tcp_setting.setText(QCoreApplication.translate("MainWindow", u"TCP", None))
        self.about.setText(QCoreApplication.translate("MainWindow", u"\u5173\u4e8e\u8f6f\u4ef6 (A)", None))
        self.help_text.setText(QCoreApplication.translate("MainWindow", u"\u67e5\u770b\u5e2e\u52a9\u6587\u6863", None))
        self.min_show.setText(QCoreApplication.translate("MainWindow", u"\u6700\u5c0f\u5316 ", None))
        self.max_show.setText(QCoreApplication.translate("MainWindow", u"\u6700\u5927\u5316", None))
        self.close.setText(QCoreApplication.translate("MainWindow", u"\u5173\u95ed (Q)                ESC", None))
        self.normal.setText(QCoreApplication.translate("MainWindow", u"\u6b63\u5e38\u5316", None))
        self.camera_show.setText(QCoreApplication.translate("MainWindow", u"\u76f8\u673a\u89c6\u89d2", None))
        self.console_show.setText(QCoreApplication.translate("MainWindow", u"\u63a7\u5236\u53f0", None))
        self.global_setting.setText(QCoreApplication.translate("MainWindow", u"\u5168\u5c40\u8bbe\u7f6e", None))
        self.out_console.setText(QCoreApplication.translate("MainWindow", u"\u5bfc\u51fa\u63a7\u5236\u53f0", None))
        self.read_image_1.setText(QCoreApplication.translate("MainWindow", u"blue", None))
        self.read_image_2.setText(QCoreApplication.translate("MainWindow", u"red", None))
        self.read_image_3.setText(QCoreApplication.translate("MainWindow", u"yellow", None))
        self.read_image_4.setText(QCoreApplication.translate("MainWindow", u"green", None))
        self.read_image_5.setText(QCoreApplication.translate("MainWindow", u"orange", None))
        self.read_image_6.setText(QCoreApplication.translate("MainWindow", u"white", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"\u8fd8\u539f\u5b57\u6bb5\uff1a", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"\u9b54\u65b9\u5b57\u6bb5\uff1a", None))
        self.cube_string.setText(QCoreApplication.translate("MainWindow", u"\u6682\u65e0\u5b57\u6bb5", None))
        self.solve_string.setText(QCoreApplication.translate("MainWindow", u"\u6682\u65e0\u5b57\u6bb5", None))
        self.send_solve.setText(QCoreApplication.translate("MainWindow", u"\u53d1\u9001\u8fd8\u539f\u65b9\u6848", None))
        self.send_mode.setItemText(0, QCoreApplication.translate("MainWindow", u"TCP\u53d1\u9001", None))
        self.send_mode.setItemText(1, QCoreApplication.translate("MainWindow", u"\u4e32\u53e3\u53d1\u9001", None))

        self.center.setTabText(self.center.indexOf(self.work), QCoreApplication.translate("MainWindow", u"\u5de5\u4f5c\u53f0", None))
        self.center.setTabText(self.center.indexOf(self.widget), QCoreApplication.translate("MainWindow", u"\u7ba1\u7406", None))
        self.menu.setTitle(QCoreApplication.translate("MainWindow", u"\u6587\u4ef6(F)", None))
        self.menu_2.setTitle(QCoreApplication.translate("MainWindow", u"\u67e5\u770b", None))
        self.menu_S.setTitle(QCoreApplication.translate("MainWindow", u"\u8bbe\u7f6e(S)", None))
        self.menu_3.setTitle(QCoreApplication.translate("MainWindow", u"\u901a\u8baf (C)", None))
        self.menu_H.setTitle(QCoreApplication.translate("MainWindow", u"\u5e2e\u52a9(H)", None))
        self.menu_4.setTitle(QCoreApplication.translate("MainWindow", u"\u8f6f\u4ef6\u4f7f\u7528\u5e2e\u52a9 (H)", None))
        self.menu_W.setTitle(QCoreApplication.translate("MainWindow", u"\u7a97\u53e3(W)", None))
        self.menu_5.setTitle(QCoreApplication.translate("MainWindow", u"\u89c6\u56fe(V)", None))
        self.console_win_view.setWindowTitle(QCoreApplication.translate("MainWindow", u"\u63a7\u5236\u53f0", None))
        self.line.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'\u5fae\u8f6f\u96c5\u9ed1'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'\u5fae\u8f6f\u96c5\u9ed1','\u5fae\u8f6f\u96c5\u9ed1';\"><br /></p></body></html>", None))
        self.send.setPlaceholderText(QCoreApplication.translate("MainWindow", u"\u56de\u8f66\u53d1\u9001 (Enter)", None))
        self.camera_view_win.setWindowTitle(QCoreApplication.translate("MainWindow", u"\u76f8\u673a\u89c6\u89d2", None))
        self.left_camera.setText(QCoreApplication.translate("MainWindow", u"\u5de6\u673a\u4f4d", None))
        self.top_camera.setText(QCoreApplication.translate("MainWindow", u"\u4e0a\u673a\u4f4d", None))
        self.video_2.setText("")
        self.video_3.setText("")
        self.video_4.setText("")
        self.right_camera.setText(QCoreApplication.translate("MainWindow", u"\u53f3\u673a\u4f4d", None))
        self.video.setText("")
        self.down_camera.setText(QCoreApplication.translate("MainWindow", u"\u4e0b\u673a\u4f4d", None))
        self.read_once.setText(QCoreApplication.translate("MainWindow", u"\u8bfb\u53d6\u4e00\u6b21", None))
        self.close_camera.setText(QCoreApplication.translate("MainWindow", u"\u5173\u95ed\u6444\u50cf\u5934", None))
        self.app_setting_win.setWindowTitle(QCoreApplication.translate("MainWindow", u"\u5168\u5c40\u8bbe\u7f6e", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"TCP\u8bbe\u7f6e", None))
        self.ip.setText(QCoreApplication.translate("MainWindow", u"192.168.137.1", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"\u670d\u52a1\u5668Ip\uff1a", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"\u7aef\u53e3\uff1a", None))
        self.port.setText(QCoreApplication.translate("MainWindow", u"7788", None))
        self.createtcp.setText(QCoreApplication.translate("MainWindow", u"\u521b\u5efa", None))
        self.about_win.setWindowTitle(QCoreApplication.translate("MainWindow", u"\u5173\u4e8e\u5e2e\u52a9", None))
        self.download_help.setText(QCoreApplication.translate("MainWindow", u"\u4e0b\u8f7d\u5e2e\u52a9\u6587\u6863", None))
    # retranslateUi

