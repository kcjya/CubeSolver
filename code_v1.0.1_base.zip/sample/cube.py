

import kociemba
#  U、R、F、D、L、B


def cubeSolve(cube_string):
    try:
        rest = kociemba.solve(cube_string)
        return rest
    except:
        return None
