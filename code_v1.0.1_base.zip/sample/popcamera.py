
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
from PySide2.QtMultimedia import *

import popcamera_ui


# 主题窗口
class PopCamera(popcamera_ui.QMainWindow):
    def __init__(self, windowtitle, parent=None):
        super(PopCamera, self).__init__(parent)
        self.popcamera_ui = popcamera_ui.Ui_MainWindow()
        self.popcamera_ui.setupUi(self)
        self.setWindowTitle(windowtitle)
        # self.setWindowFlags(Qt.WindowMinimizeButtonHint)
        self.setFixedSize(650, 650)
        self.close()

    def setVideo(self,video):
        self.popcamera_ui.video.setPixmap(video)