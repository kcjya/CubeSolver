import cv2
import numpy as np
import skimage
from skimage import morphology

from copy import deepcopy
import math
import joblib
import datetime




model_path = "./color/color.model"

clf = joblib.load(model_path) # 加载模型


def img2vector(img):
    img_arr = np.array(img)
    img_normlization = img_arr /255
    img_arr2 = np.reshape(img_normlization, (1 ,-1))
    return img_arr2

def getColor(obj_):
    img_arr = img2vector(obj_)
    retcolor = clf.predict(img_arr)

    return retcolor[0]

def colorRects(xt,yt,size,image):
    # 矩形左上角和右上角的坐标，绘制一个绿色矩形
    xb, yb = (xt + size, yt + size)
    cut_size = 20

    rect_1 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size,
             xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
    rect_2 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size,
             xt + int(size / 6 + size / 3) - cut_size:xt + int(size / 6 + size / 3) + cut_size]
    rect_3 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size,
             xt + int(size / 6 + size * 2 / 3) - cut_size:xt + int(size / 6 + size * 2 / 3) + cut_size]
    rect_4 = image[yt + int(size / 6 + size / 3) - cut_size:yt + int(size / 6 + size / 3) + cut_size,
             xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
    rect_5 = image[yt + int(size / 6 + size / 3) - cut_size:yt + int(size / 6 + size / 3) + cut_size,
             xt + int(size / 6 + size / 3) - cut_size:xt + int(size / 6 + size / 3) + cut_size]
    rect_6 = image[yt + int(size / 6 + size / 3) - cut_size:yt + int(size / 6 + size / 3) + cut_size,
             xt + int(size / 6 + size * 2 / 3) - cut_size:xt + int(size / 6 + size * 2 / 3) + cut_size]
    rect_7 = image[yt + int(size / 6 + size * 2 / 3) - cut_size:yt + int(size / 6 + size * 2 / 3) + cut_size,
             xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
    rect_8 = image[yt + int(size / 6 + size * 2 / 3) - cut_size:yt + int(size / 6 + size * 2 / 3) + cut_size,
             xt + int(size / 6 + size / 3) - cut_size:xt + int(size / 6 + size / 3) + cut_size]
    rect_9 = image[yt + int(size / 6 + size * 2 / 3) - cut_size:yt + int(size / 6 + size * 2 / 3) + cut_size,
             xt + int(size / 6 + size * 2 / 3) - cut_size:xt + int(size / 6 + size * 2 / 3) + cut_size]

    rects = [rect_1, rect_2, rect_3, rect_4, rect_5, rect_6, rect_7, rect_8, rect_9]

    return rects


def image_cv(images,return_images,results,cmdline):
    current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "] "
    cmdline.append(current + "IMAGECV: \"开始识别魔方图片...\"")
    colors = []
    for image in images:
        img = cv2.imread(image)
        # img_ = cv2.imread(image)
        # img_ = cv2.cvtColor(img_, cv2.COLOR_BGR2HSV)
        rects = colorRects(0,0,min(img.shape[0],img.shape[1]),img)
        center_color = getColor(rects[4])
        for rect in rects:
            color = getColor(rect)
            colors.append(color)
        results[center_color] = colors
        colors.clear()
        # mask = cv2.inRange(img_, hsv_range[0],hsv_range[1])
        return_images[center_color] = image

        current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "] "
        cmdline.append(current + "IMAGECV: \"No " + str(images.index(image) + 1) + " 图片读取完成\"")

    current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "] "
    cmdline.append(current + "IMAGECV: \"识别完成!\"")


def cv_1(video_data,readcube_rest,cmdline):
    current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "] "
    cmdline.append(current + "OPENCV-1: \"已经打开摄像头\"")

    capture = cv2.VideoCapture(0)  # 0为电脑内置摄像头，1为摄像头外设
    index=0
    color_list = []

    while (True):
        # image = cv2.imread("./testface.jpg")
        # 摄像头读取,ret为是否成功打开摄像头,true,false。 frame为视频的每一帧图像
        ret, frame = capture.read()
        # 摄像头是和人对立的，将图像左右调换回来正常显示。
        image = cv2.flip(frame, 1)


        # 矩形左上角和右上角的坐标，绘制一个绿色矩形
        size=420
        xt,yt = (130, 30)
        xb,yb = (130+size, 30+size)

        cv2.rectangle(image, (xt,yt), (xb,yb), (255, 0, 0), 2, 4)
        cv2.line(image, (xt,yt+int(size/3)), (xb,yt+int(size/3)), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt, yt + int(size*2 / 3)), (xb, yt + int(size*2 / 3)), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt + int(size / 3), yt), (xt + int(size / 3), yb), (255, 0, 0), 3, cv2.LINE_8)
        cv2.line(image, (xt + int(size*2 / 3), yt), (xt + int(size*2 / 3), yb), (255, 0, 0), 3, cv2.LINE_8)

        cut_size = 20
        rect_1 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
        rect_2 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_3 = image[yt + int(size / 6) - cut_size:yt + int(size / 6) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]
        rect_4 = image[yt + int(size / 6+size / 3) - cut_size:yt+int(size/6+size / 3) + cut_size, xt+int(size/6) - cut_size:xt+int(size/6) + cut_size]
        rect_5 = image[yt + int(size / 6+size / 3) - cut_size:yt + int(size / 6+size / 3) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_6 = image[yt + int(size / 6+size / 3) - cut_size:yt + int(size / 6+size / 3) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]
        rect_7 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt+int(size/6+size*2 / 3) + cut_size, xt + int(size / 6) - cut_size:xt + int(size / 6) + cut_size]
        rect_8 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt + int(size / 6+size*2 / 3) + cut_size, xt + int(size/6+size / 3) - cut_size:xt + int(size/6+size / 3) + cut_size]
        rect_9 = image[yt + int(size / 6+size*2 / 3) - cut_size:yt + int(size / 6+size*2 / 3) + cut_size, xt + int(size/6+size*2 / 3) - cut_size:xt + int(size/6+size*2 / 3) + cut_size]

        rects = [rect_1,rect_2,rect_3,rect_4,rect_5,rect_6,rect_7,rect_8,rect_9]

        color = None
        if index==9:
            current = "["+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"] "
            cmdline.append(current+"OPENCV-1: \"颜色读取完成："+str(color_list)+"\"")
            index+=1
            # break

        try:
            color = getColor(rects[index])
        except:
            pass
        if color!=None and index< 9:
            current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "] "
            cmdline.append(current+"OPENCV-1: \"No "+str(index+1)+" 方格颜色读取完成："+color+"\"")
            color_list.append(color)
            index+=1

        #共享数据
        video_data.append(image)
        # cv2.imshow("video", img)
        cv2.waitKey(1)

    # cv2.release()
    # cv2.destoryAllWindows()