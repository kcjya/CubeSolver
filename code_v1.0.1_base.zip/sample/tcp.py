
import socket
import datetime



def createTcp(ip,port,send,recv):
    if ip == None:
        ip = socket.gethostbyname(socket.gethostname())
    # 创建socket
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "]"
    recv.append(current+" SUCCEED: 已创建TCP服务器("+ip+":"+str(port)+"), 等待连接...")
    # 绑定
    server.bind((ip,int(port)))
    # 使用socket创建的套接字默认的属性是主动的，使用listen将其变为被动的，这样就可以接收别人的链接了
    server.listen(128)
    # clientAddr 是元组（ip，端口）
    client, addr = server.accept()
    current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "]"
    recv.append(current+" SUCCEED: "+str(addr)+", 已连接!")
    while True:
        if len(send)>0:
            # 发送一些数据到客户端
            client.send(str(send[0]).encode('GBK'))
            current = "[" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "]"
            recv.append(current+" SUCCEED: \""+str(send[0])+"\" 发送成功!")
            send.pop(0)


